<footer>
<nav id="nav_side_resp">
  <?php $req30=$bdd1->query("SELECT * FROM colors");
  $col=$req30->fetch();
  //backgrounds menu H
  $bacColMH=$col['bacColMH'];
  //background menu B
  $bacColMB=$col['bacColMB'];
  //color menu H
  $colMH=$col['colMH']; 
  //color menu B
  $colMB=$col['colMB'];
  //background page
  $bacColP=$col['bacColP'];
  //color page
  $colP=$col['colP']; 
  //background side
  $bacColS=$col['bacColS'];
  //color side
  $colS=$col['colS'];
  ?>
  <script>  
  //page
      //recup 
    var pageCol=document.getElementById('bloc_page');
      //background
    pageCol.style.backgroundColor="<?php echo $bacColP;?>";
      //color
    pageCol.style.color="<?php echo $colP;?>";
  //menu H
    //recup
    var menuH=document.getElementById('en_ligne_haut');

    var menuHL0=document.getElementById('lien_menuH0');
    var menuHL1=document.getElementById('lien_menuH1');
    var menuHL2=document.getElementById('lien_menuH2');
      ///background menu H
    menuH.style.backgroundColor="<?php echo $bacColMH; ?>";
        //color menu H
    menuHL0.style.color="<?php echo $colMH;?>";
    menuHL1.style.color="<?php echo $colMH;?>";
    menuHL2.style.color="<?php echo $colMH;?>";
  </script>
</nav>
<?php
if(isset($_COOKIE['accept_cookie'])) {
   $showcookie = false;
} else {
   $showcookie = true;
}
require_once('view.php');
?>
<footer>