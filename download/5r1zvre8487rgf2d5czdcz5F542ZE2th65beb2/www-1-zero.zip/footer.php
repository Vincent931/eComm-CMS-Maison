<footer>
<div style="margin:0px;border:0px" id="en_ligne">
    <div id="nav_bas1"><ul><a id="lien_menuB0" href="nous-contacter.php"><?php echo $nav_bas['contactez'];?></a></ul>
          <ul><a id="lien_menuB1" href="publicimgs/<?php echo $pdf['nom'];?>"><?php echo $nav_bas['infos'];?></a></ul>
          <ul><a id="lien_menuB2" href="politique-confidentialite.php"><?php echo $nav_bas['politique'];?></a></ul>
          <ul><a id="lien_menuB3" href="mise-en-garde.php"><?php echo $nav_bas['a_savoir'];?></a></ul>
          <ul><a id="lien_menuB4" href="reinitialisation.php"><?php echo $nav_bas['reinitialisation'];?></a></ul></div>
    <div id="nav_bas2"><?php $req40=$bdd1->query('SELECT * FROM facebook');
    $donnees60=$req40->fetch();
    if(isset($donnees60['etat']) AND !empty($donnees60['etat'])){
      if($donnees60['etat']=='oui'){
        ?><ul><?php require_once("bouton_partage_personnalise.php"); ?></ul>
     <?php }
    } ?><ul><a class="twitter-share-button" href="https://twitter.com/intent/tweet?text=Je%20tweet%20depuis" data-size="large">Tweet</a></ul></div>
</div>
			<?php $req30=$bdd1->query("SELECT * FROM colors");
			$col=$req30->fetch();
			//backgrounds menu H
			$bacColMH=$col['bacColMH'];
			//background menu B
			$bacColMB=$col['bacColMB'];
			//color menu H
			$colMH=$col['colMH']; 
			//color menu B
			$colMB=$col['colMB'];
			//background page
			$bacColP=$col['bacColP'];
			//color page
			$colP=$col['colP'];
			?>
			<script>	//recup 
						var pageCol=document.getElementById('bloc_page');
						//background
						pageCol.style.backgroundColor="<?php echo $bacColP;?>";
						pageCol.style.color="<?php echo $colP;?>";
						//recup
						var menuH=document.getElementById('en_ligne_haut');

						var menuHL0=document.getElementById('lien_menuH0');
						var menuHL1=document.getElementById('lien_menuH1');
						var menuHL2=document.getElementById('lien_menuH2');
						//background menu H
						menuH.style.backgroundColor="<?php echo $bacColMH; ?>";
						//color menu H
						menuHL0.style.color="<?php echo $colMH;?>";
						menuHL1.style.color="<?php echo $colMH;?>";
						menuHL2.style.color="<?php echo $colMH;?>";
						//recup
						var menuB=document.getElementById('en_ligne');

						var menuBL0=document.getElementById('lien_menuB0');
						var menuBL1=document.getElementById('lien_menuB1');
						var menuBL2=document.getElementById('lien_menuB2');
						var menuBL3=document.getElementById('lien_menuB3');
						var menuBL4=document.getElementById('lien_menuB4');
						//background
						menuB.style.backgroundColor="<?php echo $bacColMB;?>";
						//color
						menuBL0.style.color="<?php echo $colMB;?>";
						menuBL1.style.color="<?php echo $colMB;?>";
						menuBL2.style.color="<?php echo $colMB;?>";
						menuBL3.style.color="<?php echo $colMB;?>";
						menuBL4.style.color="<?php echo $colMB;?>";
				</script>
				<?php
if(isset($_COOKIE['accept_cookie'])) {
   $showcookie = false;
} else {
   $showcookie = true;
}
require_once('view.php');
?>
		</footer>