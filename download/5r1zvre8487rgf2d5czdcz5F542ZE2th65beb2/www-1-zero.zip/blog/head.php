<head>
      <meta charset="utf-8"/>
      <link href="../css/style.css" rel="stylesheet"/>
      <link rel="shortcut icon" href="../publicimgs/icone.png">
      <title><?php echo $title['contenu'];?></title>
      <?php $req50=$bdd->query('SELECT css FROM css');
      $donnees50=$req50->fetch();
      $css=$donnees50['css'];?>
      <style type="text/css"><? echo $css;?></style>
      <script>window.twttr = (function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0],
      t = window.twttr || {};
      if (d.getElementById(id)) return t;
      js = d.createElement(s);
      js.id = id;
      js.src = "https://platform.twitter.com/widgets.js";
      fjs.parentNode.insertBefore(js, fjs);
      t._e = [];
      t.ready = function(f) {
      t._e.push(f);
      };
      return t;
      }(document, "script", "twitter-wjs"));</script>
      <link rel="canonical" href="https://www-1-zero.fr"/>
</head>