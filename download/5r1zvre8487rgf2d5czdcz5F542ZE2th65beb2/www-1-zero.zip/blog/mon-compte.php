<?php session_start();

$old_session_id=session_id();
$_SESSION['destroyed']=time();


if(isset($_SESSION['destroyed']) AND $_SESSION['destroyed']>time()-300)
{
  session_regenerate_id();
}
require 'texte1.php';
$req20=$bdd1->query('SELECT * FROM nav_haut');
$nav_haut=$req20->fetch();
$req21=$bdd1->query('SELECT * FROM accueil');
$accueil=$req21->fetch();
$req22=$bdd1->query('SELECT * FROM nav_bas');
$nav_bas=$req22->fetch();
$req23=$bdd1->query('SELECT * FROM title');
$title=$req23->fetch();
$req26=$bdd1->query('SELECT * FROM societe');
$ste=$req26->fetch();
require 'boutique0.php';
$req25=$bdd->query('SELECT * FROM pdf');
$pdf=$req25->fetch();
if(isset($_COOKIE['mail']) AND !empty($_COOKIE['mail'])){
$_SESSION['mail']=$_COOKIE['mail'];
}
if(isset($_SESSION['mail']) AND !empty($_SESSION['mail'])){
   $z="1";
   setcookie('mail',$_SESSION['mail'], time()+ 365*24*3600,'/',null, false, true);
} else{ $_SESSION['mail']="";}




if($_SERVER['HTTP_REFERER']==$ste['url'].'/blog/mon-compte.php'){

   if(isset($_POST['formconnexion'])) {
      $mailconnect1 = htmlspecialchars($_POST['mailconnect']);
      $mailconnect= strtolower($mailconnect1);
      $mdpconnect = sha1($_POST['mdpconnect']);
      if(!empty($mailconnect) AND !empty($mdpconnect)) {
         $req = $bdd->prepare("SELECT * FROM compte WHERE mail = ? AND motdepasse = ?");
         $req->execute(array($mailconnect, $mdpconnect));
         $exist = $req->rowCount();
         if($exist > 0) {
            $donnees = $req->fetch();
            $_SESSION['pseudo'] = $donnees['pseudo'];
            $_SESSION['mail'] = $donnees['mail'];
            setcookie('mail',$_SESSION['mail'], time()+ 365*24*3600,'/',null, false, true);
            $message="Connecté";
         } else {
            $message = "Mes identifiants sont incorrects";
         }
      } else {
         $message = "Tous les champs doivent être complétés";
      }
   }

}
?>
<!DOCTYPE html>
  <html id="bloc_page">
  <?php require 'head.php';?>
    <body>
      <?php require 'menu-haut.php';?>
      </br></br></br></br>
      <div>
<h1><?php echo $ste['nom'];?></h1>
         <h2 style="text-align:center;margin:auto">Se connecter</h2>
         <div id="boutons_connect">
            <img src="../publicimgs/personne_icone.png" style="width:45px">
         </div>            
         <?php if(isset($message) AND !empty($message)){echo '<h3 style="text-align:center;margin:auto;color:red">'.$message.'</h3>'; $message="";} ?>       
            <section>
               <article>
         <form method="POST" action="">
            <p><label for="mailconnect">Email  </label><input type="email" name="mailconnect" id="mailconnect" placeholder="Mail" value="<?php echo $_SESSION['mail'];?>"/></p><br>
            <p><label for="mdpconnect">Mot de Passe  </label><input type="password" name="mdpconnect" id="mdpconnect" placeholder="Mot de passe" /></p>
            <br/><br/>
            <input type="submit" name="formconnexion" value="se connecter" />
         </form>      
         
      </article>
   </section><br><br><br>
</div>  
   <?php require 'footer.php';?>
   <?php require 'footer-resp.php';?>
   </body>
</html>
