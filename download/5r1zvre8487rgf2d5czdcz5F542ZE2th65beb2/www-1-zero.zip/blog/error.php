<DOCTYPE html>
	<html>
	<body>
	<div id="erreur"><p>GRAVE ERREUR !!! VEUILLEZ ENTRER UNE VALEUR VALIDE !!!</p></br>
		<a href="index.php">Retour aux derniers sujets</a></div>
	</body>
</html>