<?php session_start();

$old_session_id=session_id();
$_SESSION['destroyed']=time();


if(isset($_SESSION['destroyed']) AND $_SESSION['destroyed']>time()-300)
{
  session_regenerate_id();
}
require 'texte1.php';
$req20=$bdd1->query('SELECT * FROM nav_haut');
$nav_haut=$req20->fetch();
$req21=$bdd1->query('SELECT * FROM accueil');
$accueil=$req21->fetch();
$req22=$bdd1->query('SELECT * FROM nav_bas');
$nav_bas=$req22->fetch();
$req23=$bdd1->query('SELECT * FROM title');
$title=$req23->fetch();
$req26=$bdd1->query('SELECT * FROM societe');
$ste=$req26->fetch();
require 'boutique0.php';
$req25=$bdd->query('SELECT * FROM pdf');
$pdf=$req25->fetch();
?>
<!DOCTYPE html>
  <html id="bloc_page">
  <?php require 'head.php';?>
    <body>
      <?php require 'menu-haut.php';?>
      </br></br></br></br>
       <div>
         <h1><?php echo $ste['nom'];?></h1>
         <h2 style="text-align:center;margin:auto">Créer un compte</h2>
         <div id="boutons_connect">
            <img src="../publicimgs/personne_icone.png" style="width:45px">
         </div>  
         <?php if(isset($_SESSION['message'])) {echo'<h2 style="color:red;text-align:center">'.$_SESSION['message'].'</h2>';$_SESSION['message']="";}?>   
            <section>
               <article>
         
         <?php include("creer-compte.php");?>
         <table style="margin-left:auto;margin-right:auto">
            <tr style="margin-left:auto;margin-right:auto">
               <td>
               <p>Ou </p>
               <a id="grey_color"href="mon-compte.php">Je me connecte</a>
               </td>
            </tr>
         </table>
         </div>
        </br></br></br>
</article>
</section>        
    </div>  
      <?php require 'footer.php';?>
      <?php require 'footer-resp.php';?>
   </body>
</html>