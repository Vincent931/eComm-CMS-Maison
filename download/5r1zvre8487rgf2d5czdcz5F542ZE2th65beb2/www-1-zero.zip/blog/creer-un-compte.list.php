<?php session_start();

$old_session_id=session_id();
$_SESSION['destroyed']=time();


if(isset($_SESSION['destroyed']) AND $_SESSION['destroyed']>time()-300)
{
  session_regenerate_id();
}
require 'texte1.php';
$req50=$bdd1->query('SELECT * FROM societe');
$donnees50=$req50->fetch();
$nbre=strlen($donnees50['url']);
$nbre1=$nbre+25;
if(substr($_SERVER['HTTP_REFERER'],0,$nbre1)==$donnees50['url'].'/blog/creer-un-compte.php'){
require 'boutique0.php';

require 'blog2.php';

   $pseudo = htmlspecialchars($_POST['pseudo']);
   $mail_un = htmlspecialchars($_POST['mail']);
   $mail_deux = htmlspecialchars($_POST['mail2']);
   $mail1 = strtolower($mail_un);
   $mail2 = strtolower($mail_deux);
   $mdp = sha1($_POST['mdp']);
   $mdp2 = sha1($_POST['mdp2']);
   $pseudoexist=0;
   $req=$bdd->query('SELECT pseudo FROM compte');
   while($donnees=$req->fetch()){
    $pseudo1=htmlspecialchars($donnees['pseudo']);
    if($pseudo1==$pseudo){
      $pseudoexist=1;
    }
   }
if(!empty($_POST['pseudo']) AND !empty($_POST['mail']) AND !empty($_POST['mail2']) AND !empty($_POST['mdp']) AND !empty($_POST['mdp2'])) {
      $pseudolength = strlen($pseudo);
  if($pseudolength <= 255) {
    if($mail1 == $mail2) {
      if(filter_var($mail1, FILTER_VALIDATE_EMAIL)) {
      $reqmail = $bdd->prepare("SELECT * FROM compte WHERE mail = ?");
      $reqmail->execute(array($mail1));
      $mailexist = $reqmail->rowCount();
        if($mailexist == 0) {
          if($mdp == $mdp2) {
          $_SESSION['mail']=$mail1;
          $longueurKey = 19;
          $key = "";
          for($i=1;$i<$longueurKey;$i++) {
          $key .= mt_rand(0,9);
          }
            if($pseudoexist!=1) {
            setcookie('mail',$mail1, time()+ 365*24*3600,'/',null, false, true); 
            $nul="";
            $confirme=0;
            $journalise='oui';
            $req1 = $bdd->prepare('INSERT INTO compte(pseudo, mail, motdepasse, confirmkey, confirme, nom, prenom, societe, adresse1, adresse2, code_postal, ville, stateOrProvince, pays, pays_string, nom_livr, prenom_livr, societe_livr, adresse1_livr, adresse2_livr, code_postal_livr, ville_livr, stateOrProvince_livr, pays_livr, pays_livr_string, journalise) VALUES(:pseudo, :mail, :motdepasse, :confirmkey, :confirme, :nom, :prenom, :societe, :adresse1, :adresse2, :code_postal, :ville, :stateOrProvince, :pays, :pays_string, :nom_livr, :prenom_livr, :societe_livr, :adresse1_livr, :adresse2_livr, :code_postal_livr, :ville_livr, :stateOrProvince, :pays_livr, :pays_livr_string, :journalise)');
            $req1->execute(array(
              'pseudo'=>$pseudo,
              'mail'=>$mail1,
              'motdepasse'=>$mdp,
              'confirmkey'=>$key,
              'confirme'=>$confirme,
              'nom'=>$nul,
              'prenom'=>$nul, 
              'societe'=>$nul,
              'adresse1'=>$nul,
              'adresse2'=>$nul,
              'code_postal'=>$nul,
              'ville'=>$nul,
              'stateOrProvince'=>$nul,
              'pays'=>$nul,
              'pays_string'=>$nul,
              'nom_livr'=>$nul,
              'prenom_livr'=>$nul,
              'societe_livr'=>$nul,
              'adresse1_livr'=>$nul,
              'adresse2_livr'=>$nul,
              'code_postal_livr'=>$nul,
              'ville_livr'=>$nul,
              'stateOrProvince_livr'=>$nul,
              'pays_livr'=>$nul,
              'pays_livr_string'=>$nul,
              'journalise'=>$journalise));

              $req1->closeCursor();
              $_SESSION['mail']=$mail1;

$req21=$bdd1->query('SELECT compte_creation FROM mails');
$mail_creation=$req21->fetch();
$mail_confirm=$mail_creation['compte_creation'];

$req22=$bdd1->query('SELECT * FROM societe');
$ste=$req22->fetch();
$nom_ste=$ste['nom'];

$mail_ste=$ste['mail'];

$url_ste=$ste['url'];
$serveur_mail=$ste['serveur_mail'];

$mdp=$ste['mdp'];

$req23=$bdd->query('SELECT nom FROM pdf');
$pdf=$req23->fetch();
$pdf_ins=$pdf['nom'];

$pdf_insert='../publicimgs/'.$pdf_ins;

$int='bandeau-mail';
$req24=$bdd->prepare('SELECT nom FROM image WHERE intitule=?');
$req24->execute(array($int));
$donnees10=$req24->fetch();
$image=$donnees10['nom'];

require 'mail-compte.php';

$_SESSION['message']="Compte créé";
header("Location:index.php");
            } else {
                      $_SESSION['message']= "Pseudo déjà existant, Veuillez en choisir un autre.";}
          } else {
                     $_SESSION['message'] = "Vos mots de passes ne correspondent pas. Veuillez réitérer votre requête.";}
        } else {
                  $_SESSION['message'] = 'Adresse mail déjà utilisée. Veuillez réiterer votre requête.';}
      } else {
               $_SESSION['message'] = "Votre adresse mail n'est pas valide. Veuillez réitérer votre requête.";}
    } else {
            $_SESSION['message'] = "Vos adresses mail ne correspondent pas. Veuillez réitérer votre requête.";}
  } else {
         $_SESSION['message'] = "Votre pseudo ne doit pas dépasser 255 caractères. Veuillez réitérer votre requête.";}
} else {
      $_SESSION['message'] = "Tous les champs doivent être complétés. Veuillez réitérer votre requête.";}
header("Location:creer-un-compte.php");
}