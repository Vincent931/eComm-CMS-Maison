<?php session_start();

$old_session_id=session_id();
$_SESSION['destroyed']=time();


if(isset($_SESSION['destroyed']) AND $_SESSION['destroyed']>time()-300)
{
  session_regenerate_id();
}
require 'texte1.php';
$req20=$bdd1->query('SELECT * FROM nav_haut');
$nav_haut=$req20->fetch();
$req21=$bdd1->query('SELECT * FROM accueil');
$accueil=$req21->fetch();
$req22=$bdd1->query('SELECT * FROM nav_bas');
$nav_bas=$req22->fetch();
$req23=$bdd1->query('SELECT * FROM title');
$title=$req23->fetch();
$req26=$bdd1->query('SELECT * FROM societe');
$ste=$req26->fetch();
require 'boutique0.php';
$req25=$bdd->query('SELECT * FROM pdf');
$pdf=$req25->fetch();
require 'blog2.php';

$IP_blacklist='non';

$req2=$bdd2->query('SELECT * FROM blacklist');
while($donnees2=$req2->fetch()){
	if($donnees2['ip']==$_SERVER['REMOTE_ADDR']){$IP_blacklist='oui';}
}
if($IP_blacklist=='oui'){ header("Location:error-comment.php");}
?>
<!DOCTYPE html>
<html>
  <html id="bloc_page">
 <?php require 'head.php';?>
    <body>
<?php require 'menu-haut.php';?>
      </br></br></br></br><div class="vis1"><br><br></div>
      <div>
<h1>Commentaires - <?php echo $ste['nom'];?></h1>
			<h2 style="text-align:center;margin:auto">Sujets</h2>
			<div id="boutons_connect">
				<img src="../publicimgs/personne_icone.png" style="width:45px">
			</div>
  <?php if(isset($_SESSION['message'])){echo '<h3 style="text-align:center;color:red">'.$_SESSION['message'].'</h3>';$_SESSION['message']="";} ?>     
            <section>
            	<article>
<?php 
if (isset($_SESSION['id_sujet']))
{
	$_SESSION['id_sujet'] = null;
}
//on récupère les 5 derniers billets
$req = $bdd2->query('SELECT id, titre1, contenu1, DATE_FORMAT(date_creation, \'%d/%m/%Y\') AS date_creation_fr FROM topics ORDER BY id');
while ($donnees = $req->fetch())
{
?>
<table id="tab_sujet">
				<tr>
					<td>Edité le <?php echo htmlspecialchars($donnees['date_creation_fr']); ?></td>
				</tr>
				<tr>
					<td><?php echo htmlspecialchars($donnees['titre1']); ?></td>
				</tr>
				<tr><td>&nbsp;</td></tr>
				<tr>
					<td><?php echo htmlspecialchars($donnees['contenu1']); ?></td>	
				</tr>
			</br>
</table>
			<p><em><a class="a_blog_ind" style="border:1px solid black;color:black;background-color:#D0B1DC;text-decoration:none" href="commentaires.php?sujet=<?php echo htmlspecialchars($donnees['id']); ?>">Lire les avis ou écrire ...</a></em></p>

<?php
} //fin de la boucle des billets

$req->closeCursor();
?></br></br></br><br><br>
		</article>
		</section>
		<?php require 'footer.php';?>
		<?php require 'footer-resp.php';?>
    <br><br><br><br><br>
		</div>
	</body>
</html>