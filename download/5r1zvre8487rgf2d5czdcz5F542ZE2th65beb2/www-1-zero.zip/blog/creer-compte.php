<?php ?>	</br></br></br></br>

			<form class="form_cr_compte" method="POST" action="creer-un-compte.list.php">
				<p><label for="mail">Votre adresse mail </label><input type="mail" name="mail" id="mail"/></p>
				<p><label for="mail2">Confirmation mail </label><input type="email" id="mail2" name="mail2"/></p>
				<p><label for="pseudo">Choisissez un pseudo </label><input type="text" name="pseudo" id="pseudo"/></p>
				<p><label for="mdp">Mot de passe </label><input type="password" placeholder="Je crée mon MdP" id="mdp" name="mdp"/></p>
	            <p><label for="mdp2">Mot de passe </label><input type="password" placeholder="Je confirme mon MdP" id="mdp2" name="mdp2"/></p></br>
				<p style="text-align:center"><input style="border:1px solid black" type="submit" value="Valider"/></p>
			</form>