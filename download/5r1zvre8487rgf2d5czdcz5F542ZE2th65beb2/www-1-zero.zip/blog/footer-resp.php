  
<footer>
<nav id="nav_side_resp">
  <?php $req30=$bdd1->query("SELECT * FROM colors");
  $col=$req30->fetch();
  //backgrounds menu H
  $bacColMH=$col['bacColMH'];
  //background menu B
  $bacColMB=$col['bacColMB'];
  //color menu H
  $colMH=$col['colMH']; 
  //color menu B
  $colMB=$col['colMB'];
  //background page
  $bacColP=$col['bacColP'];
  //color page
  $colP=$col['colP']; 
  //background side
  $bacColS=$col['bacColS'];
  //color side
  $colS=$col['colS'];
  ?>
  <ul>
    <li><a id="lien_side0n" href="index.php">Sujets/Accueil</a></li>
    <li><a id="lien_side1n" href="mon-compte.php">Se Connecter</a></li>
    <li><a id="lien_side2n" href="deconnect-page.php">Déconnecter</a></li>
    <li><a id="lien_side3n" href="creer-un-compte.php">Créer un Compte</a></li>
    <li><a id="lien_side4n" href="../facture.php">Factures</a></li>
    <li><a id="lien_menuB0n" href="../nous-contacter.php"><?php echo $nav_bas['contactez'];?></a></li>
    <li><a id="lien_menuB1n" href="../publicimgs/<?php echo $pdf['nom'];?>"><?php echo $nav_bas['infos'];?></a></li>
    <li><a id="lien_menuB2n" href="../politique-confidentialite.php"><?php echo $nav_bas['politique'];?></a></li>
    <li><a id="lien_menuB3n" href="../mise-en-garde.php"><?php echo $nav_bas['a_savoir'];?></a></li>
    <li><a id="lien_menuB4n" href="../reinitialisation.php"><?php echo $nav_bas['reinitialisation'];?></a></li>
    <?php $req40=$bdd1->query('SELECT * FROM facebook');
    $donnees60=$req40->fetch();
    if(isset($donnees60['etat']) AND !empty($donnees60['etat'])){
      if($donnees60['etat']=='oui'){
        ?><li id="lien_menuB5n"><?php require("../bouton_partage_personnalise.php"); ?></li>
         <?php }
    } ?>
    <li><a class="twitter-share-button" href="https://twitter.com/intent/tweet?text=Je%20tweet%20depuis" data-size="large">Tweet</a></li>
  <ul>
  <script>  
  //page
      //recup 
    var pageCol=document.getElementById('bloc_page');
      //background
    pageCol.style.backgroundColor="<?php echo $bacColP;?>";
      //color
    pageCol.style.color="<?php echo $colP;?>";
  //menu H
    //recup
    var menuH=document.getElementById('en_ligne_haut');

    var menuHL0=document.getElementById('lien_menuH0');
    var menuHL1=document.getElementById('lien_menuH1');
    var menuHL2=document.getElementById('lien_menuH2');
      ///background menu H
    menuH.style.backgroundColor="<?php echo $bacColMH; ?>";
        //color menu H
    menuHL0.style.color="<?php echo $colMH;?>";
    menuHL1.style.color="<?php echo $colMH;?>";
    menuHL2.style.color="<?php echo $colMH;?>";
  //menu B attaché au side
    //background nav_side_resp de bacColMB (bdd)
    var menuB=document.getElementById('nav_side_resp');
    menuB.style.backgroundColor="<?php echo $bacColMB;?>";
    //color nav_side_resp
    var menuS0=document.getElementById('lien_side0n');
    menuS0.style.color="<?php echo $colMB;?>";
    var menuS1=document.getElementById('lien_side1n');
    menuS1.style.color="<?php echo $colMB;?>";
    var menuS2=document.getElementById('lien_side2n');
    menuS2.style.color="<?php echo $colMB;?>";
    var menuS3=document.getElementById('lien_side3n');
    menuS3.style.color="<?php echo $colMB;?>";
    var menuS4=document.getElementById('lien_side4n');
    menuS4.style.color="<?php echo $colMB;?>";
    var menuBL0=document.getElementById('lien_menuB0n');
    menuBL0.style.color="<?php echo $colMB;?>";
    var menuBL1=document.getElementById('lien_menuB1n');
    menuBL1.style.color="<?php echo $colMB;?>";
    var menuBL2=document.getElementById('lien_menuB2n');
    menuBL2.style.color="<?php echo $colMB;?>";
    var menuBL3=document.getElementById('lien_menuB3n');
    menuBL3.style.color="<?php echo $colMB;?>";
    var menuBL4=document.getElementById('lien_menuB4n');
    menuBL4.style.color="<?php echo $colMB;?>";
  </script>
</nav>
<footer>