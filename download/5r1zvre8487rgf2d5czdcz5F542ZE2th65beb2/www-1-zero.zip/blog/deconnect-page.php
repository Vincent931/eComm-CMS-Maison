<?php session_start();
session_destroy();
session_unset();
require 'texte1.php';
$req20=$bdd1->query('SELECT * FROM nav_haut');
$nav_haut=$req20->fetch();
$req21=$bdd1->query('SELECT * FROM accueil');
$accueil=$req21->fetch();
$req22=$bdd1->query('SELECT * FROM nav_bas');
$nav_bas=$req22->fetch();
$req23=$bdd1->query('SELECT * FROM title');
$title=$req23->fetch();
$req26=$bdd1->query('SELECT * FROM societe');
$ste=$req26->fetch();
require 'boutique0.php';
$req25=$bdd->query('SELECT * FROM pdf');
$pdf=$req25->fetch();
require 'blog2.php';
?>
<!DOCTYPE html>
  <html id="bloc_page">
  <?php require 'head.php';?>
    <body>
      <?php require 'menu-haut.php';?>

      </br></br></br></br>

<h1><?php echo $ste['nom'];?></h1>
			
			<h2 style="text-align:center">Se déconnecter</h2>
			<div id="boutons_connect">
				<img src="../publicimgs/personne_icone.png" style="width:45px">
			</div>        
      <section>
        <article>
          <h2 style="text-align:center;color:red">Déconnecté...</h2>
				</article>
			</section>
<br><br>  
    <?php require 'footer.php';?>
    <?php require 'footer-resp.php';?>
  </body>
</html>