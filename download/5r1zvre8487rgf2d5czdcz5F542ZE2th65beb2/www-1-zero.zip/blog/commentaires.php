<?php session_start();

$old_session_id=session_id();
$_SESSION['destroyed']=time();


if(isset($_SESSION['destroyed']) AND $_SESSION['destroyed']>time()-300)
{
  session_regenerate_id();
}
require 'texte1.php';
$req20=$bdd1->query('SELECT * FROM nav_haut');
$nav_haut=$req20->fetch();
$req21=$bdd1->query('SELECT * FROM accueil');
$accueil=$req21->fetch();
$req22=$bdd1->query('SELECT * FROM nav_bas');
$nav_bas=$req22->fetch();
$req23=$bdd1->query('SELECT * FROM title');
$title=$req23->fetch();
$req26=$bdd1->query('SELECT * FROM societe');
$ste=$req26->fetch();
require 'boutique0.php';
$req25=$bdd->query('SELECT * FROM pdf');
$pdf=$req25->fetch();
require 'blog2.php';

if(isset($_COOKIE['mail']) AND !empty($_COOKIE['mail'])){
	$_SESSION['mail']=$_COOKIE['mail'];
}

$IP_blacklist='non';

$req2=$bdd2->query('SELECT * FROM blacklist');
while($donnees2=$req2->fetch()){
	if($donnees2['ip']==$_SERVER['REMOTE_ADDR']){$IP_blacklist='oui';}
}
if($IP_blacklist=='oui'){ header("Location:error-comment.php");}
?>
<!DOCTYPE html>
  <html id="bloc_page">
  <?php require 'head.php';?>
    <body>
      <?php require 'menu-haut.php';?>
      </br></br></br></br>
      <div>
<h1>Commentaires - <?php echo $ste['nom'];?></h1>
			
			<div id="boutons_connect">
				<img src="../publicimgs/personne_icone.png" style="width:45px">
			</div>
            <section>
            	<article>
            		<h2 style="text-align:center">Sujet</h2>
<?php if(isset($_SESSION['message'])){echo '<h3 style="text-align:center;color:red">'.$_SESSION['message'].'</h3>';$_SESSION['message']="";}
// Connexion à la base de données

//1eres conditions de securite
if (isset($_GET['sujet']))	//isset sur $_GET['sujet'] et attribution de la variable $id_sujet
	{
		$id_sujet = htmlspecialchars(urldecode($_GET['sujet']));
		$id_sujet = (int) ($id_sujet);
	}
elseif (   ( (isset($donnees['id'])) AND (isset($_GET['sujet'])) ) OR (isset($donnees['id']))   )	//isset sur $donnees['id']
	{
		$id_sujet = htmlspecialchars($donnees['id']);
	}
elseif ( isset($_SESSION['id_sujet']))	//attribution de $id_billet avec $_SESSION['id_sujet'] venu de commentaires_post.php']
	{
		$id_sujet = htmlspecialchars($_SESSION['id_sujet']);	//quel que soit la variable d'entrée en sortie = $id_sujet
	}
if (isset($_POST['pseudo_envoi']))
	{
			$_POST['pseudo_envoi'] = null;	//on attribue $_COOKIE['pseudo'] de $_POST['pseudo_envoi'] venu de commentaires_post.php
	}

//récupération du billet avec prepare
$req = $bdd2->prepare('SELECT id, titre1, contenu1, DATE_FORMAT(date_creation, \'%d/%m/%Y\') AS date_creation_fr FROM topics WHERE id =:id_sujet');
//on récupère la requête dans un array $id_sujet rentré en URL sur index.php ou venu de commentaires_post.php
$req->execute(array(
'id_sujet' => $id_sujet));
$donnees = $req->fetch();

	?>
<table id="tab_sujet">
				<tr>
					<td>Edité le <?php echo htmlspecialchars($donnees['date_creation_fr']); ?></td>
				</tr>
				<tr>
					<td><?php echo htmlspecialchars($donnees['titre1']); ?></td>
				</tr>
				<tr>
					<td><?php echo htmlspecialchars($donnees['contenu1']); ?></td>	
				</tr>
			</br>
</table>

				<h3 style="text-align:center; margin:auto">Derniers commentaires :</h3>
<?php
//récupération des commentaires avec une requete preparée
$req = $bdd2->prepare('SELECT pseudo, message, DATE_FORMAT(date_creation_message, \'%d/%m/%Y à %Hh%imin%ss\') As date_creation_message_fr FROM commentaires WHERE id_sujet = :id_sujet ORDER BY date_creation_message DESC');
$req->execute(array(
'id_sujet' => $id_sujet)); //ici on utilise l'id de billets rentré en url qui correspond à id_billet dans la bdd commentaires
while ($donnees = $req->fetch())
			
		{
		?><table id="tab_sujet_comment">
				<tr>
					<td>Ecrit le <?php echo htmlspecialchars($donnees['date_creation_message_fr']); ?> Par: <?php echo htmlspecialchars($donnees['pseudo']); ?></td>
				</tr>
				<tr>
					<td>Message/Article : <?php echo htmlspecialchars($donnees['message']); ?></td>	
				</tr>
			</br>
</table>
		<?php
		}
//Fin de boucle de récupération des 5 derniers commentaires
$req->closeCursor();
		?>
	<form class="form_blog_comment" action="commentaires.post.php" method="post">

	<p style="text-align:right"><label for="mail">Mail </label><input type="text" name="mail" id="mail" value="<?php if(isset($_SESSION['mail'])) {echo htmlspecialchars($_SESSION['mail']);} ?>"/></p>
	
	<p style="text-align:right"><label for="mdp">Mot de Passe </label><input type="password" name="mdp" id="mdp"/></p>
					
	<p style="text-align:right;margin:auto"><textarea class="area_blog_comment" name="message_envoi" rows="10" cols="50">Message ...</textarea></p>

    <input type="hidden" name="id_sujet" value="<?php if(isset($id_sujet)) {echo htmlspecialchars($id_sujet);} ?>"/>

	<p style="text-align:center"><input style="margin-top:1.25%"type="submit" value="Envoyer" /></p>
          

	</form>
</article>
</section>
</div> 
<br><br><br><br><br>
    <?php require 'footer.php';?>
    <?php require 'footer-resp.php';?>
   </body>
</html>
