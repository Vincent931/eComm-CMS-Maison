<div style="background-color:black; height:100%">
<h1 style="margin:auto width:300px;text-align:center;color:red">ERROR quelque-chose s'est mal passé</h1>
</div>