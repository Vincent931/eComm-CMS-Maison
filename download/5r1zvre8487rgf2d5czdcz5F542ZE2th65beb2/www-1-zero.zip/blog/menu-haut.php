<div id="en_ligne_haut">
   <nav>
      <ul><a href="../index.php"><img style="width:45px"src="../publicimgs/accueil.png"/></a></ul>
      <ul><a id="lien_menuH0" href="../tarifs.php"><?php echo $nav_haut['tarifs'];?></a></ul>
      <ul><a id="lien_menuH2" href="index.php"><?php echo $nav_haut['blog'];?></a></ul>
   </nav>
</div>
