-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  sam. 08 fév. 2020 à 20:15
-- Version du serveur :  10.4.6-MariaDB
-- Version de PHP :  7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `vvhv1249_boutique`
--

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id` int(11) NOT NULL,
  `reduction` varchar(8) NOT NULL DEFAULT '0.00',
  `livr_inter` varchar(4) NOT NULL,
  `reference` varchar(12) NOT NULL,
  `ref2` varchar(255) NOT NULL,
  `cle_image` varchar(255) NOT NULL,
  `titre` text NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix` varchar(14) NOT NULL,
  `TVA` varchar(7) NOT NULL,
  `sous_total` varchar(14) NOT NULL,
  `total` varchar(14) NOT NULL,
  `livraison` varchar(7) NOT NULL,
  `grand_total` varchar(11) NOT NULL,
  `poids` int(11) NOT NULL,
  `etat` varchar(4) NOT NULL,
  `acheteur` varchar(255) NOT NULL,
  `mac` varchar(41) NOT NULL,
  `telechar` varchar(255) NOT NULL,
  `date_com` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

CREATE TABLE `compte` (
  `id` int(11) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `mail` text NOT NULL,
  `motdepasse` text NOT NULL,
  `confirmkey` bigint(21) NOT NULL,
  `confirme` int(2) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `societe` text NOT NULL,
  `adresse1` text NOT NULL,
  `adresse2` text NOT NULL,
  `code_postal` varchar(7) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `stateOrProvince` varchar(255) NOT NULL,
  `pays` varchar(255) NOT NULL,
  `pays_string` varchar(255) NOT NULL,
  `nom_livr` varchar(255) NOT NULL,
  `prenom_livr` varchar(255) NOT NULL,
  `societe_livr` text NOT NULL,
  `adresse1_livr` text NOT NULL,
  `adresse2_livr` text NOT NULL,
  `code_postal_livr` varchar(6) NOT NULL,
  `ville_livr` varchar(255) NOT NULL,
  `stateOrProvince_livr` varchar(255) NOT NULL,
  `pays_livr` varchar(255) NOT NULL,
  `pays_livr_string` varchar(255) NOT NULL,
  `journalise` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `css`
--

CREATE TABLE `css` (
  `id` int(11) NOT NULL,
  `css` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `css`
--

INSERT INTO `css` (`id`, `css`) VALUES
(3, '/******************* css add *************/&#10;&#10;&#10;&#10;&#10;/****************************************/&#10;/***Add CSS********/\n&#10;&#10;');

-- --------------------------------------------------------

--
-- Structure de la table `download`
--

CREATE TABLE `download` (
  `id` int(11) NOT NULL,
  `exist` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `download`
--

INSERT INTO `download` (`id`, `exist`) VALUES
(2, 'non');

-- --------------------------------------------------------

--
-- Structure de la table `explications`
--

CREATE TABLE `explications` (
  `id` int(11) NOT NULL,
  `id_produit` int(11) NOT NULL,
  `precisiona` text NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `image3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `intitule` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `image`
--

INSERT INTO `image` (`id`, `intitule`, `nom`, `description`) VALUES
(89, 'labelF', 'logo.png', 'Label Facture'),
(94, 'contact', 'contact.jpg', 'Image Contact'),
(95, 'icone', 'icone.png', 'Icone du site'),
(96, 'bandeau', 'bandeau.png', 'Bandeau du site'),
(97, 'bandeau-mail', 'bandeau-mail.png', 'Bandeau du site'),
(98, 'caddie', 'caddie.png', 'Caddie Achat Image'),
(99, 'monnaie', 'monnaie.png', 'Monnaie Achat Image'),
(100, 'comments', 'comments.png', 'Precisions Image'),
(101, 'accueil', 'accueil.png', 'Accueil Image');

-- --------------------------------------------------------

--
-- Structure de la table `incident_paiement`
--

CREATE TABLE `incident_paiement` (
  `id` int(11) NOT NULL,
  `montant` varchar(14) NOT NULL,
  `date_incident` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `music`
--

CREATE TABLE `music` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `nbre_reduction`
--

CREATE TABLE `nbre_reduction` (
  `id` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `nbre` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `operande`
--

CREATE TABLE `operande` (
  `id` int(11) NOT NULL,
  `titre` text NOT NULL,
  `quantite` int(16) NOT NULL,
  `reference` varchar(13) NOT NULL,
  `acheteur` varchar(255) NOT NULL,
  `date_com` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `operande2`
--

CREATE TABLE `operande2` (
  `id` int(11) NOT NULL,
  `reference` varchar(13) NOT NULL,
  `ref2` varchar(255) NOT NULL,
  `livraison` varchar(12) NOT NULL,
  `etat` varchar(4) NOT NULL,
  `acheteur` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `pdf`
--

CREATE TABLE `pdf` (
  `id` int(1) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `afficher` varchar(4) NOT NULL,
  `cle_image` varchar(255) NOT NULL,
  `titre` text NOT NULL,
  `description` text NOT NULL,
  `prix` text NOT NULL,
  `TVA` varchar(7) NOT NULL,
  `promotion` varchar(4) NOT NULL,
  `quantite` int(11) NOT NULL,
  `livraison` varchar(7) NOT NULL,
  `livraison_associe` varchar(7) NOT NULL,
  `livraison_poly` varchar(7) NOT NULL,
  `livr_inter` varchar(11) NOT NULL,
  `poids` int(11) NOT NULL,
  `date_creation` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `prod_solo`
--

CREATE TABLE `prod_solo` (
  `id` int(11) NOT NULL,
  `afficher` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reduction`
--

CREATE TABLE `reduction` (
  `id` int(11) NOT NULL,
  `coupon` varchar(255) NOT NULL,
  `valeur` varchar(8) NOT NULL,
  `minimum` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `telechargement`
--

CREATE TABLE `telechargement` (
  `id` int(11) NOT NULL,
  `cle` bigint(14) NOT NULL,
  `facteur` int(3) NOT NULL,
  `file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `upload`
--

CREATE TABLE `upload` (
  `id` int(11) NOT NULL,
  `intitule` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `video`
--

CREATE TABLE `video` (
  `id` int(11) NOT NULL,
  `image0` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `compte`
--
ALTER TABLE `compte`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `css`
--
ALTER TABLE `css`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `download`
--
ALTER TABLE `download`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `explications`
--
ALTER TABLE `explications`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `incident_paiement`
--
ALTER TABLE `incident_paiement`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `music`
--
ALTER TABLE `music`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `nbre_reduction`
--
ALTER TABLE `nbre_reduction`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `operande`
--
ALTER TABLE `operande`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `operande2`
--
ALTER TABLE `operande2`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pdf`
--
ALTER TABLE `pdf`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `prod_solo`
--
ALTER TABLE `prod_solo`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `reduction`
--
ALTER TABLE `reduction`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `telechargement`
--
ALTER TABLE `telechargement`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `upload`
--
ALTER TABLE `upload`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1526;

--
-- AUTO_INCREMENT pour la table `compte`
--
ALTER TABLE `compte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT pour la table `css`
--
ALTER TABLE `css`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `download`
--
ALTER TABLE `download`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `explications`
--
ALTER TABLE `explications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;

--
-- AUTO_INCREMENT pour la table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT pour la table `incident_paiement`
--
ALTER TABLE `incident_paiement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `music`
--
ALTER TABLE `music`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `nbre_reduction`
--
ALTER TABLE `nbre_reduction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT pour la table `operande`
--
ALTER TABLE `operande`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1175;

--
-- AUTO_INCREMENT pour la table `operande2`
--
ALTER TABLE `operande2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=545;

--
-- AUTO_INCREMENT pour la table `pdf`
--
ALTER TABLE `pdf`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `produits`
--
ALTER TABLE `produits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT pour la table `prod_solo`
--
ALTER TABLE `prod_solo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `reduction`
--
ALTER TABLE `reduction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `telechargement`
--
ALTER TABLE `telechargement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT pour la table `upload`
--
ALTER TABLE `upload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `video`
--
ALTER TABLE `video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
