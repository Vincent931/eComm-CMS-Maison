-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  jeu. 06 fév. 2020 à 09:48
-- Version du serveur :  10.4.6-MariaDB
-- Version de PHP :  7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `vvhv1249_texte`
--

-- --------------------------------------------------------

--
-- Structure de la table `accueil`
--

CREATE TABLE `accueil` (
  `id` int(1) NOT NULL,
  `contenu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `accueil`
--

INSERT INTO `accueil` (`id`, `contenu`) VALUES
(1, '<div>\r\n<div style=\"background-color:#9B619C;width:100%;margin-top:25px;margin-bottom:25px;padding:0;border:0; width:100%;display:block\">Site www-1-zero.fr</div>\r\n<h1 style=\"color:blue\">Hello World !!!</h1>\r\n</div>');

-- --------------------------------------------------------

--
-- Structure de la table `adresses`
--

CREATE TABLE `adresses` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `a_savoir`
--

CREATE TABLE `a_savoir` (
  `id` int(1) NOT NULL,
  `contenu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `a_savoir`
--

INSERT INTO `a_savoir` (`id`, `contenu`) VALUES
(1, '<p>CGVente</p>\r\n<h2 style=\"text-align: right; margin-right: 13px\">www-1-zero</h2></br></br>');

-- --------------------------------------------------------

--
-- Structure de la table `campagne`
--

CREATE TABLE `campagne` (
  `id` int(11) NOT NULL,
  `contenu` text NOT NULL,
  `subject` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `campagne`
--

INSERT INTO `campagne` (`id`, `contenu`, `subject`, `image`) VALUES
(4, 'ceci est un email de test', 'sujet', 'test.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `colors`
--

CREATE TABLE `colors` (
  `id` int(1) NOT NULL,
  `bacColMH` varchar(255) NOT NULL,
  `colMH` varchar(255) NOT NULL,
  `bacColMB` varchar(255) NOT NULL,
  `colMB` varchar(255) NOT NULL,
  `bacColP` varchar(255) NOT NULL,
  `colP` varchar(255) NOT NULL,
  `bacColS` varchar(255) NOT NULL,
  `colS` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `colors`
--

INSERT INTO `colors` (`id`, `bacColMH`, `colMH`, `bacColMB`, `colMB`, `bacColP`, `colP`, `bacColS`, `colS`) VALUES
(1, '#C1D3FA', 'white', '#C1D3FA', 'white', '#F3F8F8', 'black', '#C1D3FA', 'white');

-- --------------------------------------------------------

--
-- Structure de la table `contactez`
--

CREATE TABLE `contactez` (
  `id` int(1) NOT NULL,
  `contenu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `contactez`
--

INSERT INTO `contactez` (`id`, `contenu`) VALUES
(1, 'Vous pouvez me contacter en <a style=\"text-decoration:underline;color:#3792E1\" href=\"email.php\">cliquant ici</a>\r\n</br></br>\r\n	\r\n');

-- --------------------------------------------------------

--
-- Structure de la table `desinscrire`
--

CREATE TABLE `desinscrire` (
  `id` int(11) NOT NULL,
  `cle` bigint(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `facebook`
--

CREATE TABLE `facebook` (
  `id` int(3) NOT NULL,
  `etat` varchar(4) NOT NULL,
  `image` varchar(255) NOT NULL,
  `titre` text NOT NULL,
  `description` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `nom_site` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `google_mp`
--

CREATE TABLE `google_mp` (
  `id` int(3) NOT NULL,
  `exist` varchar(4) NOT NULL,
  `lat` varchar(30) NOT NULL,
  `lon` varchar(30) NOT NULL,
  `api` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `mails`
--

CREATE TABLE `mails` (
  `id` int(1) NOT NULL,
  `vente` text NOT NULL,
  `compte_creation` text NOT NULL,
  `reinitialisation` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `mails`
--

INSERT INTO `mails` (`id`, `vente`, `compte_creation`, `reinitialisation`) VALUES
(1, 'Bonjour, vous avez fait un achat sur monsite.fr', 'Vous avez cree un compte sur monsite.fr', '<br> ');

-- --------------------------------------------------------

--
-- Structure de la table `monetico`
--

CREATE TABLE `monetico` (
  `id` int(4) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `TPE` varchar(50) NOT NULL,
  `version` varchar(5) NOT NULL,
  `url` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `url_web` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `nav_bas`
--

CREATE TABLE `nav_bas` (
  `id` int(1) NOT NULL,
  `contactez` varchar(255) NOT NULL,
  `infos` varchar(255) NOT NULL,
  `politique` varchar(255) NOT NULL,
  `a_savoir` varchar(255) NOT NULL,
  `reinitialisation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `nav_bas`
--

INSERT INTO `nav_bas` (`id`, `contactez`, `infos`, `politique`, `a_savoir`, `reinitialisation`) VALUES
(2, 'Contact', 'PDF Société', 'Politique de confidentialité', 'CGV', 'Compte Initialisation');

-- --------------------------------------------------------

--
-- Structure de la table `nav_haut`
--

CREATE TABLE `nav_haut` (
  `id` int(1) NOT NULL,
  `tarifs` varchar(255) NOT NULL,
  `blog` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `nav_haut`
--

INSERT INTO `nav_haut` (`id`, `tarifs`, `blog`) VALUES
(2, 'Magasin', 'Compte / Commentaires');

-- --------------------------------------------------------

--
-- Structure de la table `paypal`
--

CREATE TABLE `paypal` (
  `id` int(11) NOT NULL,
  `environnement` varchar(255) NOT NULL,
  `marchand_id` varchar(255) NOT NULL,
  `cle_publique` varchar(255) NOT NULL,
  `cle_prive` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `paypal`
--

INSERT INTO `paypal` (`id`, `environnement`, `marchand_id`, `cle_publique`, `cle_prive`) VALUES
(1, 'sandbox', '521gf4p153vgttf', 'jhgvb654hcf', 'utfvut54hcrf');

-- --------------------------------------------------------

--
-- Structure de la table `politique`
--

CREATE TABLE `politique` (
  `id` int(1) NOT NULL,
  `contenu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `politique`
--

INSERT INTO `politique` (`id`, `contenu`) VALUES
(1, '<h1>Politique de confidentialité</h1>');

-- --------------------------------------------------------

--
-- Structure de la table `publicite1`
--

CREATE TABLE `publicite1` (
  `id` int(3) NOT NULL,
  `image` varchar(255) NOT NULL,
  `texte` text NOT NULL,
  `bouton` varchar(4) NOT NULL,
  `id_prod` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `publicite2`
--

CREATE TABLE `publicite2` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `texte` text NOT NULL,
  `bouton` varchar(4) NOT NULL,
  `id_prod` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reterror`
--

CREATE TABLE `reterror` (
  `id` int(1) NOT NULL,
  `contenu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `reterror`
--

INSERT INTO `reterror` (`id`, `contenu`) VALUES
(1, '<p>Votre Paiement est annulé, quelquechose s\'est mal passé.</br>\r\n    Vérifier votre carte et vos capacités de Paiement.</p>\r\n');

-- --------------------------------------------------------

--
-- Structure de la table `retok`
--

CREATE TABLE `retok` (
  `id` int(1) NOT NULL,
  `contenu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `retok`
--

INSERT INTO `retok` (`id`, `contenu`) VALUES
(1, '<p><span style=\"color:blue\">Votre Paiement est validé :</span></br>\r\nVous recevrez un mail de confirmation dans les minutes qui viennent.</br>\r\n</p>\r\n\r\n');

-- --------------------------------------------------------

--
-- Structure de la table `societe`
--

CREATE TABLE `societe` (
  `id` int(11) NOT NULL,
  `dossier` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `sigle` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `serveur_mail` varchar(255) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `adresse1` varchar(255) NOT NULL,
  `adresse2` varchar(255) NOT NULL,
  `CP` varchar(255) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `pays` varchar(255) NOT NULL,
  `RCS` varchar(255) NOT NULL,
  `ville_RCS` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `title`
--

CREATE TABLE `title` (
  `id` int(11) NOT NULL,
  `contenu` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `accueil`
--
ALTER TABLE `accueil`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `adresses`
--
ALTER TABLE `adresses`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `a_savoir`
--
ALTER TABLE `a_savoir`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `campagne`
--
ALTER TABLE `campagne`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `contactez`
--
ALTER TABLE `contactez`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `desinscrire`
--
ALTER TABLE `desinscrire`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `facebook`
--
ALTER TABLE `facebook`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `google_mp`
--
ALTER TABLE `google_mp`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `mails`
--
ALTER TABLE `mails`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `monetico`
--
ALTER TABLE `monetico`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `nav_bas`
--
ALTER TABLE `nav_bas`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `nav_haut`
--
ALTER TABLE `nav_haut`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paypal`
--
ALTER TABLE `paypal`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `politique`
--
ALTER TABLE `politique`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `publicite1`
--
ALTER TABLE `publicite1`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `publicite2`
--
ALTER TABLE `publicite2`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `reterror`
--
ALTER TABLE `reterror`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `retok`
--
ALTER TABLE `retok`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `societe`
--
ALTER TABLE `societe`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `title`
--
ALTER TABLE `title`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `accueil`
--
ALTER TABLE `accueil`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `adresses`
--
ALTER TABLE `adresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `a_savoir`
--
ALTER TABLE `a_savoir`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `campagne`
--
ALTER TABLE `campagne`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `colors`
--
ALTER TABLE `colors`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `contactez`
--
ALTER TABLE `contactez`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `desinscrire`
--
ALTER TABLE `desinscrire`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `facebook`
--
ALTER TABLE `facebook`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `google_mp`
--
ALTER TABLE `google_mp`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `mails`
--
ALTER TABLE `mails`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `monetico`
--
ALTER TABLE `monetico`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `nav_bas`
--
ALTER TABLE `nav_bas`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `nav_haut`
--
ALTER TABLE `nav_haut`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `paypal`
--
ALTER TABLE `paypal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `politique`
--
ALTER TABLE `politique`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `publicite1`
--
ALTER TABLE `publicite1`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `publicite2`
--
ALTER TABLE `publicite2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `reterror`
--
ALTER TABLE `reterror`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `retok`
--
ALTER TABLE `retok`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `societe`
--
ALTER TABLE `societe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `title`
--
ALTER TABLE `title`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
