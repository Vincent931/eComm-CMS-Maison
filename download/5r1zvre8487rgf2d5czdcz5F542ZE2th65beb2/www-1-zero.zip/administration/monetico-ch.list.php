<?php session_start();

require 'texte1.php';
if(isset($_POST['hash'])AND !empty($_POST['hash'])){
	if(isset($_POST['TPE'])AND !empty($_POST['TPE'])){
		if(isset($_POST['version'])AND !empty($_POST['version'])){
			if(isset($_POST['url'])AND !empty($_POST['url'])){
				if(isset($_POST['code'])AND !empty($_POST['code'])){
					if(isset($_POST['url_web'])AND !empty($_POST['url_web'])){
$hash=$_POST['hash'];
$TPE=$_POST['TPE'];
$version=$_POST['version'];
$url=$_POST['url'];
$code=$_POST['code'];
$url_web=$_POST['url_web'];

$req=$bdd1->query('SELECT * FROM monetico');
$donnees=$req->fetch();

if(isset($donnees['hash']) AND !empty($donnees['hash'])){
	$req1=$bdd1->prepare('UPDATE monetico SET hash=:hash, TPE=:TPE, version=:version, url=:url, code=:code, url_web=:url_web');
	$req1->execute(array('hash'=>$hash, 'TPE'=>$TPE, 'version'=>$version, 'url'=>$url, 'code'=>$code, 'url_web'=>$url_web));
} else {
	$req1=$bdd1->prepare('INSERT INTO monetico(hash, TPE, version, url, code, url_web) VALUES(?, ?, ?, ?, ? ,?)');
	$req1->execute(array($hash, $TPE, $version, $url, $code, $url_web));
}
$_SESSION['message']="Valeurs ajoutées.";

header("Location: monetico-ch.php");
					} else{$_SESSION['message']="Remplissez le champs clé de hashage";header("Location:monetico-ch.php");}
				} else{$_SESSION['message']="Remplissez le champs TPE";header("Location:monetico-ch.php");}
			} else{$_SESSION['message']="Remplissez le champs version";header("Location:monetico-ch.php");}
		} else{$_SESSION['message']="Remplissez le champs url monético";header("Location:monetico-ch.php");}
	} else{$_SESSION['message']="Remplissez le champs code société";header("Location:monetico-ch.php");}
} else{$_SESSION['message']="Remplissez le champs url site";header("Location:monetico-ch.php");}				