<?php session_start();
require 'boutique0.php';
require 'blog2.php';
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
	<body>
		<div>
      <h1>Espace d'administration</h1>
  <?php require 'menu-haut.php';?>
</br></br></br></br>
			<h2>Modification sujet</h2>
			<div id="boutons_connect">
				<img src="../publicimgs/personne_icone.png" style="width:45px">
				<tr>
					<td>
						<a style="border:1px solid black;color:white;text-decoration:none;background-color:#B058CE" href="../index.php">Aller sur le site</a>
					</td>
				</tr>
			</div></br>
			<p><?php if(isset($_SESSION['message'])){echo '<h3 style="text-align:center">'.$_SESSION['message'].'</h3>';$_SESSION['message']="";} ?></p></br>

<?php if (isset($_POST['id_modifier']) AND !empty($_POST['id_modifier'])) {
$id_modifier=htmlspecialchars($_POST['id_modifier']);
			
$req=$bdd2->prepare('SELECT * FROM topics WHERE id=?');
$req->execute(array($id_modifier));
$donnees = $req->fetch();
?>
	<form method="POST" action="modification-sujet.list2.php">
		<div>
		<p><label for="date_creation">Date de création de la forme aaaa/mm/jj </label></p>
		<p><input style="border:1px solid black" type="date" name="date_creation" id="date_creation" value="<?php echo htmlspecialchars($donnees['date_creation']); ?>"/></p>
		<p><label for="titre1">Titre </label></p>
		<p><textarea style="border:1px solid black" type="text" name="titre1" id="titre1" rows="2" cols="75"><?php echo htmlspecialchars($donnees['titre1']); ?></textarea></p>
		<p><label for="contenu1">Contenu </label></p>
		<p><textarea style="border:1px solid black" type="text" name="contenu1" id="contenu1" rows="6" cols="75"><?php echo htmlspecialchars($donnees['contenu1']); ?></textarea></p>
		<input type="hidden" name="id_modifier" id="id_modifier" value="<?php echo $id_modifier; ?>"/>
		</br></br>
		<input type="submit" value="Changer sujet"/>
		</div>
	</form>	
	</br>
<?php
}
$req->closeCursor();
?>	
		</div>
      <br><br><br><br><br>
	</body>
</html>