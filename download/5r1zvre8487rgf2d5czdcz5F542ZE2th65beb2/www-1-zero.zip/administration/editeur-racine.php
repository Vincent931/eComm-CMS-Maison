<div style="display:inline-block">
  <div style="display:inline:block">
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<h1>','','</h1>');">h1</a>
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<h2>','','</h2>');">h2</a>
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<h3>','','</h3>');">h3</a>
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<p>','','</p>');">Paragraphe</a>
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<span style=&quot;text-decoration:underline&quot;>','','</span>');">Souligné</a>
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<span style=&quot;font-style:bold&quot;>','','</span>');">Gras</a>
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<em>','','</em>');">Italique</a>
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<a href=&quot;https://urlainserer.com&quot;>','','</a>');">Lien</a>
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<a id=&quot;grey_color&quot; href=&quot;https://urlainserer.com&quot;>','','</a>');">Lien bouton</a>
    <a style="border:1px solid black;background-color:#DDE3E3;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<a style=&quot;text-decoration:underline;color:#3792E1&quot; href=&quot;email.php&quot;>','','</a>');">MailTo</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">à gauche</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','<img src=&quot;publicimgs/exempledenom.jpg&quot; style=&quot;text-align:left;border-radius:10px/10px;border:1px solid black&quot;/>','');">Image</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">centré</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','<img src=&quot;publicimgs/exempledenom.jpg&quot; style=&quot;text-align:center;border-radius:10px/10px;border:1px solid black&quot;/>','');">Image</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">à droite</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','<img src=&quot;publicimgs/exempledenom.jpg&quot; style=&quot;text-align:right;border-radius:10px/10px;border:1px solid black&quot;/>','');">Image</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">Flottant à gauche</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','<img src=&quot;publicimgs/exempledenom.jpg&quot; style=&quot;text-align:left;border-radius:10px/10px;border:1px solid black;float:left&quot;/>','');">Image</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">Flottant à droite</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','<img src=&quot;publicimgs/exempledenom.jpg&quot; style=&quot;text-align:left;border-radius:10px/10px;border:1px solid black;float:right&quot;/>','');">Image</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">id valeur de 100px (un)</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','id=&quot;un&quot;','');">img src="" id=100px</a>
  </div>
   <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">id valeur de 200px (deux)...etc</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','id=&quot;deux&quot;','');">img src="" id=200px</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">id valeur 1200px (douze)</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','id=&quot;douze&quot;','');">img src="" id=1200px</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">Clear left</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<div style=&quot;clear:left&quot;>','','</div>');">Texte dessous</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">Clear Right</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('<div style=&quot;clear:right&quot;>','','</div>');">Image</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">Vidéo</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','<video src=&quot;publicimgs/video.mp4&quot; controls poster=&quot;publicimgs/imageassocie.jpg&quot; width=&quot;300&quot;></video>','');">MP4</a>
  </div>
  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">ex Youtube</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','<iframe width=&quot;560&quot; height=&quot;315&quot; src=&quot;https://www.youtube.com/embed/y94CtKuGG_Q&quot; frameborder=&quot;0&quot; allow=&quot;accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture&quot; allowfullscreen></iframe>','');">youtube ex:</a>
  </div>
   <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">Musique</span>
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="javascript:AddText('','<audio src=&quot;publicimgs/musique.mp3&quot; controls width=&quot;300&quot;></audio>','');">MP3</a>
  </div>
  <div style="display:inline-block">
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="image-bank.php" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=250px,height=360'); return false;">Image Bank</a> 
  </div>
  <div style="display:inline-block">
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="videos-bank.php" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=250px,height=360'); return false;">MP4 Bank</a> 
  </div>
  <div style="display:inline-block">
    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;color:black;text-decoration:none" href="music-bank.php" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=250px,height=360'); return false;">MP3 Bank</a> 
  </div>
</div>