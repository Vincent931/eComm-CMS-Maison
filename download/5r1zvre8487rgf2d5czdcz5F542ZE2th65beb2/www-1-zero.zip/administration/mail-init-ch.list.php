<?php session_start();
$mail_init=$_POST['message'];
require 'texte1.php';

$req=$bdd1->prepare('UPDATE mails SET compte_creation=:compte_creation');
$req->execute(array('compte_creation'=>$mail_init));

$_SESSION['message']="email modifié";
header('Location:mail-init-ch.php');