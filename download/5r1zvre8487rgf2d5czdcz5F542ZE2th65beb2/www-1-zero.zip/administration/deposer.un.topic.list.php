<?php session_start();

if (!empty($_POST['titre_envoi']) AND !empty($_POST['contenu_envoi']))
			{
					$titre = htmlspecialchars($_POST['titre_envoi']);
					$contenu = htmlspecialchars($_POST['contenu_envoi']);

					require 'blog2.php';
					
					//écriture du billet avec prepare
					$req = $bdd2->prepare('INSERT INTO topics(titre1, contenu1, date_creation) VALUES (?, ?, NOW())');
					$req->execute(array($titre, $contenu));
					$req->closeCursor();
					header("Location: effacer-sujet.php");
					
			} else { $_SESSION['erreur']='Vous devez remplir tous les champs'; 
		header("Location: deposer.un.topic.php"); }
?>