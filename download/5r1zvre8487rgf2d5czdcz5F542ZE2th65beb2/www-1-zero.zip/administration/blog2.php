<?php
require '../signifiant.php';
try
{
	$bdd2 = new PDO('mysql:host=localhost;dbname=vvhv1249_blog;charset=utf8', $admin, $keypass);
}
catch(Exception $e)
{
	die('Erreur : '.$e->getMessage());
}
