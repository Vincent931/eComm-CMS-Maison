<div style="display:inline-block">
	  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">Saut Ligne</span>
	    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;text-decoration:none;color:black" href="javascript:AddText('','<br>','');">br</a>
	  </div>
	  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">à gauche</span>
	    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;text-decoration:none;color:black" href="javascript:AddText('','<img src=&quot;../publicimgs/exempledenom.jpg&quot; style=&quot;text-align:left;border-radius:10px/10px;border:1px solid black&quot;/>','');">Image</a>
	  </div>
	  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">centré</span>
	    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;text-decoration:none;color:black" href="javascript:AddText('','<img src=&quot;../publicimgs/exempledenom.jpg&quot; style=&quot;text-align:center;border-radius:10px/10px;border:1px solid black&quot;/>','');">Image</a>
	  </div>
	  <div style="display:inline-block"><span style="margin-top:10px;margin-bottom:5px;padding:5px;background-color:#EFD5AB;display:block">à droite</span>
	    <a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;text-decoration:none;color:black" href="javascript:AddText('','<img src=&quot;../publicimgs/exempledenom.jpg&quot; style=&quot;text-align:right;border-radius:10px/10px;border:1px solid black&quot;/>','');">Image</a>
	  </div>
	  <div style="display:inline-block">
    	<a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;text-decoration:none;color:black" href="image-bank.php" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=250px,height=360'); return false;">Image Bank</a> 
		</div>
	</div>