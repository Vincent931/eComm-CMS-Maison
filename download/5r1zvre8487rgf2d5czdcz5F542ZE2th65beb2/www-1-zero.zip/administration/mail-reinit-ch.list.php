<?php session_start();
$mail_init=$_POST['message'];
require 'texte1.php';

$req=$bdd1->prepare('UPDATE mails SET reinitialisation=:reinitialisation');
$req->execute(array('reinitialisation'=>$mail_init));

$_SESSION['message']="email modifié";
header('Location:mail-reinit-ch.php');