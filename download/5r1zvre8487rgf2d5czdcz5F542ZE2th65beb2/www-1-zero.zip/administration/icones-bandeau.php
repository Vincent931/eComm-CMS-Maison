<?php session_start();
require 'boutique0.php'; 
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
	<body>
		<div>
      <h1>Espace d'administration</h1>
  <?php require 'menu-haut.php';?>
</br></br></br></br>
			<h2 style="text-align:center">Accueil</h2>
			<div id="boutons_connect">
				<img src="../publicimgs/personne_icone.png" style="width:45px">
				<tr>
					<td>
						<a style="border:1px solid black;color:white;text-decoration:none;background-color:#B058CE" href="../index.php">Aller sur le site</a>
					</td>
				</tr>
<?php if(isset($_SESSION['message'])){echo '<h3 style="text-align:center;color:red">'.$_SESSION['message'].'</h3>';$_SESSION['message']="";} ?>
			</div></br>
			<p>Pour changer l'icône visible sur les onglets de navigateur cochez icône (~ 50px x 50px</p>
			<p>Pour changer le bandeau visible dans les e-mails (tous les cients de messagerie ne l'affichent pas) cochez bandeau (~ 400px x 180px { L x H })</p>
			<p>Pour changer l'image présente sur la page contact cochez label ( ~ 200px x 200px )</p>
			<p>Pour changer l'icône caddie cochez caddie (~ 50px x 50px )</p>
			<p>Pour changer l'icône monnaie cochez monnaie (~ 50px x 50px )</p>
			<p>Pour changer l'icône Précisions cochez Précisions ( ~ 50px x 50px )</p>
			<p>Penser à effacer vos cookies entre les affichages d'images !!!</p>

			<form class="form_icons" action="ch-icons.php" method="post" enctype="multipart/form-data">
				<p>Quelle image interne changez-vous?</p>
				<div class="icones_ch">

		        <label for="contact">1-Contact</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		        <input type="radio" name="changerImage" id="contact" value="contact"/></br>

				<label for="icone">2-Icône</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="radio" name="changerImage" id="icone" value="icone"/></br>

				<label for="labelF">3-Label Facture</label>&nbsp;&nbsp;
				<input type="radio" name="changerImage" id="labelF"  value="labelF"/></br>

				<label for="bandeau">4-Bandeau</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="radio" name="changerImage" id="bandeau" value="bandeau"/></br>

				<label for="panier">5-Caddie</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="radio" name="changerImage" id="panier" value="caddie"/></br>
				
				<label for="panier2">6-Monnaie</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="radio" name="changerImage" id="panier2" value="monnaie"/></br>

				<label for="comments">7-Precisions</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="radio" name="changerImage" id="comments" value="comments"/></br>

		        <label for="accueil">8-Accueil</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		        <input type="radio" name="changerImage" id="accueil" value="accueil"/></br></br>

				<p><label for="image">Sélectionnez image (.jpg pour 1, .png pour 2,3,4,5,6,7) </label>
		        <input type="file" name="image" id="image"/></p>

		        <p><label for="description">Description de l'image</label>
		        <input type="text" name="description" id="description"/></p>

      			<input type="submit" value="changer-image"/>
				</div>
			</form>

			
	</div>
    <br><br><br><br><br>
</body>
</html>