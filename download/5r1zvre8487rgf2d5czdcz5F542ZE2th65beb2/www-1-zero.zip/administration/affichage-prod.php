<table id="largeur_table">
		<tr>
			<td><img style="text-align:center;width:450px;border-radius:25px/25px;border:1px solid black;margin-left:auto;margin-right:auto" src="../publicimgs/<?php if($ifpromo=='oui'){echo 'promo-'.htmlspecialchars($donnees['cle_image']);}else{echo htmlspecialchars($donnees['cle_image']);} ?>"/></td>
			<td>
			<p style="color:blue"><?php echo 'ID : '.htmlspecialchars($donnees['id']); ?></p>
			<?php if(isset($mot)){if($mot=='telechargement'){echo '<p style="color:blue">'.'Nom Téléchargement : '.$charge.'</p>'; }}?>
			<p><?php echo 'Afficher dans la boutique : '.htmlspecialchars($donnees['afficher']); ?></p>
			<p><?php echo 'Nom-image produit : '.htmlspecialchars($donnees['cle_image']); ?></p>
			<p><?php echo htmlspecialchars($donnees['titre']); ?></p>
			<p><?php echo htmlspecialchars($donnees['description']); ?></p>
			<p><?php echo 'Prix TTC (€) : '.htmlspecialchars($donnees['prix']); ?></p>
			<p><?php echo 'Taux TVA (ex: 0.055 ou 0.206) : '.htmlspecialchars($donnees['TVA']); ?>
			<p><?php echo 'Promotion : '.htmlspecialchars($donnees['promotion']); ?></p>
			<p><?php echo 'Quantité : '.htmlspecialchars($donnees['quantite']); ?></p>
			<p><?php echo 'Livraison unique (€) : '.htmlspecialchars($donnees['livraison']); ?></p>
			<p><?php echo 'Livraison double (=x2) (€) : '.htmlspecialchars($donnees['livraison_associe']); ?></p>
			<p><?php echo 'Poly-Livraison (=x3 ou +) (€) : '.htmlspecialchars($donnees['livraison_poly']); ?></p>
			<p><?php echo 'Livraison internationale au kg (€) : '.htmlspecialchars($donnees['livr_inter']); ?></p>
			<p><?php echo 'poids en grammes (+emballages) : '.htmlspecialchars($donnees['poids']);?></p>
			<p><?php echo 'Ajouté le : '.htmlspecialchars($donnees['date_creation']); ?></p>
			<p><?php echo 'Explications : '.htmlspecialchars($donnees2['precisiona']); ?></p>
			<p><?php echo 'Nom de l\'image 1 : '.htmlspecialchars($donnees2['image1']); ?></p>
			<p><?php echo 'Nom de l\'image 2 : '.htmlspecialchars($donnees2['image2']); ?></p>
			<p><?php echo 'Nom de l\'image 3 : '.htmlspecialchars($donnees2['image3']); ?></p>
			</td>
		</tr>
	</table>