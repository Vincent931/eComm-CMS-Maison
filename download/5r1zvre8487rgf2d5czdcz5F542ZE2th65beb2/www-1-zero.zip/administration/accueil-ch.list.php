<?php session_start();

$position=$_POST['position'];

require 'texte1.php';

$contenu=$_POST['message'];

$req=$bdd1->prepare('UPDATE accueil SET contenu=:contenu');
$req->execute(array('contenu'=>$contenu));

$_SESSION['message']="Page enregistré";
header("Location:accueil-ch.php?position=".$position);