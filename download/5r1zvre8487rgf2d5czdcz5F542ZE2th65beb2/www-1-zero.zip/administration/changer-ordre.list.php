<?php session_start(); 

require 'boutique0.php';

if(isset($_POST['ordre']) AND !empty($_POST['ordre']))

{

$k=intval($_POST['compteur']);
echo $k;

$i=0;

while($i<$k)

{

$i++;
$ordre="";

$inp="";
$inp="ordre".$i;
$ordre=$_POST[$inp];
echo $ordre.'--';
	
$req=$bdd->prepare('SELECT * FROM produits WHERE id=?');
$req->execute(array($ordre));
$donnees3=$req->fetch();


$afficher = $donnees3['afficher'];
$cle_image = $donnees3['cle_image'];
$titre = $donnees3['titre'];
$description = $donnees3['description'];
$prix = $donnees3['prix'];
$TVA = $donnees3['TVA'];
$promotion = $donnees3['promotion'];
$quantite = $donnees3['quantite'];
$livraison = $donnees3['livraison'];
$livraison_associe = $donnees3['livraison_associe'];
$livraison_poly = $donnees3['livraison_poly'];
$livr_inter = $donnees3['livr_inter'];
$poids = $donnees3['poids'];
$date_creation = $donnees3['date_creation'];

$req4 = $bdd->prepare('INSERT INTO produits(afficher, cle_image, titre, description, prix, TVA, promotion, quantite, livraison, livraison_associe, livraison_poly, livr_inter, poids, date_creation) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

$req4->execute(array($afficher, $cle_image, $titre, $description, $prix, $TVA, $promotion, $quantite, $livraison, $livraison_associe, $livraison_poly, $livr_inter, $poids, $date_creation));

$req5=$bdd->query('SELECT * FROM produits');
while($donnees4=$req5->fetch()) {
$_SESSION['id']=htmlspecialchars($donnees4['id']);
}

$req6=$bdd->prepare('UPDATE explications SET id_produit=:id_new WHERE id_produit=:id_produit');
$req6->execute(array('id_new'=>$_SESSION['id'], 'id_produit'=>$ordre));


$req7=$bdd->prepare('DELETE FROM produits WHERE id=?');
$req7->execute(array($ordre));

}
	
$_SESSION['message']='Produits déplacés';

}
header("Location: changer-ordre.php");
/*echo $afficher.'--'.$cle_image.'--'.$titre.'--'.$description.'--'.$prix.'--'.$TVA.'--'.$promotion.'--'.$quantite.'--'.$livraison.'--'.$livraison_associe.'--'.$livraison_poly.'--'.$livr_inter.'--'.$poids.'--'.$date_creation;
*/
//echo 'anc='.$ordre.' new='.$_SESSION['id'];
?>
