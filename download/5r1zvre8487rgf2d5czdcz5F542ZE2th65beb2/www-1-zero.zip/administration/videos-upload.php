<?php session_start();
require 'boutique0.php';
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
  <body>
    <div>
      <h1>Espace d'administration</h1>
  <?php require 'menu-haut.php';?>
</br></br></br></br>
			<h2 style="text-align:center">Uploader Vidéo</h2>
			<div id="boutons_connect">
				<img src="../publicimgs/personne_icone.png" style="width:45px">
				<tr>
					<td>
						<a style="border:1px solid black;color:white;text-decoration:none;background-color:#B058CE" href="../index.php">Aller sur le site</a>
					</td>
				</tr>
<?php if(isset($_SESSION['message'])){echo '<h3 style="text-align:center;color:red">'.$_SESSION['message'].'</h3>';$_SESSION['message']="";} ?>
			</div></br>
    	<p>Choisissez un vidéo MP4(codec vidéo H.264, codec son MP3)</p>
     	<p>Mettez les valeurs PHP de votre serveur à :</p>
      	<p>Max_file_upload: 256M</p>
  	  	<p>Memory_limit: 1024M</p>
  	  	<p>Post_max_size: 512M</p>
  	  	<p>Upload_max_filesize: 212M</p>
  	  </br>
		<div style="display:inline-block">
    		<a style="display:block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;text-decoration:none;color:black" href="image-bank.php" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=250px,height=360'); return false;">Image Bank</a> 
		</div>
        <form style="text-align:right;margin:auto;width:550px" method="post" action="videos-upload.list.php" enctype="multipart/form-data">
          <p><label for="video">Vidéo (.mp4)</label>
          <input type="file" name="video" id="video"/></p>
          <p><label for="nameF">Nom à donner à cette vidéo (sans le .mp4)</label>
          <input type="text" name="nameF" id="nameF"/></p>
          <p><label for="description">Description de la vidéo</label>
          <input type="text" name="description" id="description"/></p>
          <p><label for="image">Image de présentation de la vidéo</label>
          <input type="text" name="image" id="image"/></p>
          <p style="text-align:center"><input type="submit" name="submit" value="Charger"/></p>
        </form>

</div>
  <br><br><br><br><br>
  </body>
</html>