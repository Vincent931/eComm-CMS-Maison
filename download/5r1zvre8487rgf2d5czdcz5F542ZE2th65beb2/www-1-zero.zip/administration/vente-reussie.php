<?php session_start();
require 'texte1.php';
require 'boutique0.php';
require 'blog2.php';
$req26=$bdd1->query('SELECT * FROM societe');
$ste=$req26->fetch();
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
  <body>
    <div>
      <h1>Espace d'administration</h1>
  <?php require 'menu-haut.php';?>
</br></br></br></br>
         <h2 style="text-align:center">Produits Vendus - Acheteurs </h2>
         <tbody>
         
            <tr>
               <td>
                  <a style="border:1px solid black;color:white;text-decoration:none;background-color:#B058CE" href="../index.php">Aller sur le site</a>
               </td>
            </tr>
            </tbody>
         
   <section>
      <article>
      	<tbody>
<?php
if(isset($_GET['ref']) AND isset($_GET['mail']) AND !empty($_GET['ref']) AND !empty($_GET['mail'])){
    $ref=urldecode($_GET['ref']);
    $acheteur=urldecode($_GET['mail']);
	?><h3 style="text-align:center">Produits vendus et Totaux</h3>
	<?php
    $req= $bdd->prepare('SELECT reduction, reference, titre, prix, quantite, sous_total, total,  livraison, grand_total, DATE_FORMAT(date_com, \'%d/%m/%Y\') AS date_com FROM commande WHERE reference=? AND acheteur=?');
    $req->execute(array($ref, $acheteur));  
while($donnees=$req->fetch()){
	?><table style="margin:auto;">
		<tr>
			<td colspan="3"><h5>Vente à: <?php echo $acheteur;?> du: <?php echo htmlspecialchars($donnees['date_com']);?></h5></td>
		</tr>
		<tr>
			<td colspan="3">Produit: <?php echo htmlspecialchars($donnees['titre']);?></td>
		</tr>
		<tr>
			<td><?php echo htmlspecialchars($donnees['prix']);?>€</td>
		</tr>
		<tr>
			<td>quantite: <?php echo htmlspecialchars($donnees['quantite']);?></td>
		</tr>
		<tr>
			<td>sous-total: <?php echo htmlspecialchars($donnees['sous_total']);?>€</td>
      	</tr>
      	<tr>
      	<td>référence vente: <?php echo htmlspecialchars($donnees['reference']);?></td>
		</tr>

	<?php
	$req1= $bdd->prepare('SELECT quantite FROM produits WHERE titre=?');
	$titre=htmlspecialchars($donnees['titre']);
	$req1->execute(array($titre));
	$donnees1=$req1->fetch();
	$stock=htmlspecialchars($donnees1['quantite']);
	?>
	<tr>
		<td colspan="3">Reste en stock: <?php echo $stock;?></td>
	</tr>
	</br/>
	</table>
<?php $totalv=htmlspecialchars($donnees['total']);
$livraison= htmlspecialchars($donnees['livraison']);
if(isset($donnees['reduction']) AND !empty($donnees['reduction'])){$reduction=htmlspecialchars($donnees['reduction']);}
$grand_total=htmlspecialchars($donnees['grand_total']);
} ?>
<table style="margin:auto">
    <tr>
		<td>Total = <?php echo $totalv;?>€</td>
	</tr>
    <tr>
        <td>Livraison = <?php echo $livraison; ?>€</td>
    </tr>
     <?php if(isset($reduction) AND !empty($reduction)){echo '<tr>'.
        '<td>'.'Réduction = '.$reduction.'€'.'</td>'.
    '</tr>';}?>
    <tr>
        <td>Grand Total = <?php echo $grand_total; ?>€</td>
    </tr>
	</br>
</table>
<?php
	$req2= $bdd->prepare('SELECT * FROM compte WHERE mail=?');
    $req2->execute(array($acheteur));
    $donnees=$req2->fetch();
    ?>
    <table style="margin:auto;">
    <tr><td colspan="2"><h3 style="text-align:center">CLIENT</h3></td></tr>
	<tr><td colspan="2">Nom Acheteur: <?php echo htmlspecialchars($donnees['nom']).'   Prénom: '.htmlspecialchars($donnees['prenom']);?></td></tr></br>
	<tr><td colspan="2">Société: <?php echo htmlspecialchars($donnees['societe']);?></td></tr>
	<tr><td colspan="2">Adresse: <?php echo htmlspecialchars($donnees['adresse1']);?></td></tr>
	<tr><td colspan="2"><?php echo htmlspecialchars($donnees['adresse2']);?></td></tr>
	<tr><td colspan="2"><?php echo htmlspecialchars($donnees['code_postal']).'   '.htmlspecialchars($donnees['ville']);?></td></tr>
  <?php if(isset($donnees['stateOrProvince'])AND !empty($donnees['stateOrProvince'])){echo'<tr>'.'<td>'.$donnees['stateOrProvince'].'</td>'.'</tr>';}?>
  <tr><td colspan="2"><?php echo htmlspecialchars($donnees['pays_string']);?></td></tr>
	</br>
	<tr><td colspan="2"><h3 style="text-align:center">Adresse de Livraison </h3></td></tr>
	<tr><td colspan="2">Nom Client à livrer: <?php echo htmlspecialchars($donnees['nom_livr']).'   Prénom: '.htmlspecialchars($donnees['prenom_livr']);?></td></tr>
	<tr><td colspan="2">Société: <?php echo htmlspecialchars($donnees['societe_livr']);?></td></tr>
	<tr><td colspan="2">Adresse: <?php echo htmlspecialchars($donnees['adresse1_livr']);?></td></tr>
	<tr><td colspan="2"><?php echo htmlspecialchars($donnees['adresse2_livr']);?></td></tr>
	<tr><td colspan="2"><?php echo htmlspecialchars($donnees['code_postal_livr']).'   '.htmlspecialchars($donnees['ville_livr']);?></td></tr>
  <?php if(isset($donnees['stateOrProvince_livr'])AND !empty($donnees['stateOrProvince_livr'])){echo'<tr>'.'<td colspan="2">'.$donnees['stateOrProvince_livr'].'</td>'.'</tr>';}?>
  <tr><td colspan="2"><?php echo htmlspecialchars($donnees['pays_livr_string']);?></td></tr>
<?php
$req->closeCursor();
$req1->closeCursor();
$req2->closeCursor();
?><tr><td><a id="grey_color" style="border:1px solid black;color:black;text-decoration:none" href="<?php echo $ste['url'];?>/administration/facture-vendeur.php?mail=<?php echo urlencode($acheteur);?>&ref=<?php echo urlencode($ref);?>" alt="user" target="_blank">Editer une facture</a></td>
<td><a id="grey_color" style="border:1px solid black;color:black;text-decoration:none" href="<?php echo $ste['url'];?>/administration/bon-livraison.php?mail=<?php echo urlencode($acheteur);?>&ref=<?php echo urlencode($ref);?>" alt="user" target="_blank">Editer un bon de Livraison</a></td></tr>
</table>
<?php
} else {echo "Un problème est survenu, contacter un développeur.";}
?>
  <br><br><br><br><br>
			</tbody>
      	</article>
   	</section>
   	</div>

      
   </body>
</html>