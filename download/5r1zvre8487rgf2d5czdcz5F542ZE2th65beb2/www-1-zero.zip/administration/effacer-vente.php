<?php session_start(); 

require 'boutique0.php';
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
	<body>
		<div>
      <h1>Espace d'administration</h1>
  <?php require 'menu-haut.php';?>
</br></br></br></br>
<?php if(isset($_SESSION['message'])){echo '<h3 style="text-align:center">'.$_SESSION['message'].'</h3>';$_SESSION['message']="";} ?>
			</div></br>
			<form method="post" action="">
			<input type="hidden" name="confirmer" id="confirmer" value="oui"/>
			<input type="submit" value="Je confirme l'effacement"/>
			<form></br>
			</br>
		</br>
	<a id="grey_color" href="stock-factures.php">Annulez l'effacement ici</a>
		</div>
      <br><br><br><br><br>
	</body>
</html>
<?php
if(isset($_POST['confirmer']) AND !empty($_POST['confirmer'])){

if (isset($_GET['mail']) AND !empty($_GET['mail']) AND isset($_GET['ref']) AND !empty($_GET['ref']))
			{				
					
					$acheteur=htmlspecialchars(urldecode($_GET['mail']));
					$ref=htmlspecialchars(urldecode($_GET['ref']));
					
					//écriture du billet avec prepare
					$req = $bdd->prepare('DELETE FROM commande WHERE reference=? AND acheteur=?');
					$req->execute(array($ref, $acheteur));
					$req->closeCursor();
					header("Location:stock-factures.php");
					
					
			} else { $_SESSION['message']='ERRREUR de données GET sur stock-factures.php';header("Location:stock-factures.php");}
}


?>