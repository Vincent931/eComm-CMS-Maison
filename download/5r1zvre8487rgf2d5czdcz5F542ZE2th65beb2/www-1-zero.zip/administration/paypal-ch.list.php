<?php session_start();
require 'texte1.php';

$environnement=$_POST['environnement'];
$marchand_id=$_POST['marchand_id'];
$cle_publique=$_POST['cle_publique'];
$cle_prive=$_POST['cle_prive'];

if(isset($_POST['environnement']) AND !empty($_POST['environnement'])){
	if(isset($_POST['marchand_id']) AND !empty($_POST['marchand_id'])){
		if(isset($_POST['cle_publique']) AND !empty($_POST['cle_publique'])){
			if(isset($_POST['cle_prive']) AND !empty($_POST['cle_prive'])){

				$req=$bdd1->query('SELECT * FROM paypal');
				$donnees=$req->fetch();
				if(isset($donnees['environnement']) AND !empty($donnees['environnement'])){

					$req1=$bdd1->prepare('UPDATE paypal SET environnement=:environnement, marchand_id=:marchand_id, cle_publique=:cle_publique, cle_prive=:cle_prive');
					$req1->execute(array('environnement'=>$environnement, 'marchand_id'=>$marchand_id, 'cle_publique'=>$cle_publique, 'cle_prive'=>$cle_prive));

				} else {

					$req1=$bdd1->prepare('INSERT INTO paypal(environnement, marchand_id, cle_publique, cle_prive) VALUES(:environnement, :marchand_id, :cle_publique, :cle_prive)');
					$req1->execute(array('environnement'=>$environnement, 'marchand_id'=>$marchand_id, 'cle_publique'=>$cle_publique, 'cle_prive'=>$cle_prive));
				}
				$_SESSION['message']="Données Chargées";

			} else { $_SESSION['message']="Remplissez le champ clé privé";header("Location:paypal-ch.php");}
		} else { $_SESSION['message']="Remplissez le champ clé publique";header("Location:paypal-ch.php");}
	} else { $_SESSION['message']="Remplissez le champ id marchand";header("Location:paypal-ch.php");}
} else { $_SESSION['message']="Remplissez le champ environnement";header("Location:paypal-ch.php");}
header("Location:paypal-ch.php");