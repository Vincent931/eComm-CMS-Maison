<?php session_start(); 

require 'boutique0.php';

$_SESSION['compteur']=0;
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
	<body>
		<div>
      <h1>Espace d'administration</h1>
  <?php require 'menu-haut.php';?>
</br></br></br></br>
			<h2 style="text-align:center">Modification de Téléchargement</h2>
			<div id="boutons_connect">
				<tr>
					<td>
						<a style="border:1px solid black;color:white;text-decoration:none;background-color:#B058CE" href="../index.php">Aller sur le site</a>
					</td>
				</tr>

			</div></br>
<?php 
if(isset($_SESSION['message'])){echo '<h3 style="text-align:center">'.$_SESSION['message'].'</h3>';$_SESSION['message']="";}
?>
<div style="display:inline-block">
    <a style="display:inline-block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;text-decoration:none;color:black" href="image-bank.php" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=250px,height=360'); return false;">Image Bank</a>
    <a style="display:inline-block;border:1px solid black;background-color:#DDE3E3;margin-top:5px;margin-bottom:5px;padding:5px;text-decoration:none;color:black" href="download-bank.php" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=250px,height=360'); return false;">Fichier Bank</a>
</div>
<br><br>
<form style="width:550px;margin:auto;text-align:right" method="POST" action="modification-telechargement.list.php">
				<p><label for="id_modifier">Numéro </label><input type="number" name="id_modifier" id="id_modifier"/></p>
				<p style="text-align:center"><input type="submit" value="Envoyer"/></p>
</form>
<?php

$req = $bdd->query('SELECT id, nom, afficher, cle_image, titre, description, prix, TVA, promotion, quantite, livraison, livraison_associe, livraison_poly, livr_inter, poids, DATE_FORMAT(date_creation, \'%d/%m/%Y\') AS date_creation FROM produits ORDER BY id');
while ($donnees = $req->fetch())
	{
	$mot=substr($donnees['nom'],0,14);
	if($mot=="telechargement"){

	if($donnees['promotion']=='oui'){
		$ifpromo="oui";
	} else {$ifpromo="non";}

	$req2=$bdd->prepare('SELECT * FROM explications WHERE id_produit=?');
	$req2->execute(array(htmlspecialchars($donnees['id'])));
	$donnees2=$req2->fetch();
	$mot=substr($donnees['nom'],0,14);
	$charge=substr($donnees['nom'],14,255);
	require 'affichage-prod.php'; 
	require 'affichage-explic.php';
}
} 
$req->closeCursor();
?>

		<br><br><br><br><br>
		</div>
	</body>
</html>