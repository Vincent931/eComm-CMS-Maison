<head>
    <meta charset="utf-8"/>
    <link href="../css/style.css" rel="stylesheet"/>
    <link rel="shortcut icon" href="../publicimgs/icone.png"/>
    <title>Boutique-Administration</title>
    <?php $req50=$bdd->query('SELECT css FROM css');
    $donnees50=$req50->fetch();
    $css=$donnees50['css'];?>
    <style type="text/css"><? echo $css;?></style>
    <script language="JavaScript" type="text/javascript">


function AddText(startTag,defaultText,endTag)
{
   with(document.ch_form)
   {
      if (message.createTextRange)
      {
         var text;
         message.focus(message.caretPos);
         message.caretPos = document.selection.createRange().duplicate();
         if(message.caretPos.text.length>0)
         {
            //gère les espaces de fin de sélection. Un double-click sélectionne le mot
            //+ un espace qu'on ne souhaite pas forcément...
            var sel = message.caretPos.text;
            var fin = '';
            while(sel.substring(sel.length-1, sel.length)==' ')
            {
               sel = sel.substring(0, sel.length-1)
               fin += ' ';
            }
            message.caretPos.text = startTag + sel + endTag + fin;
         }
         else
            message.caretPos.text = startTag+defaultText+endTag;
      }
      //MOZILLA/NETSCAPE support
      else if (message.selectionStart || message.selectionStart == "0")
      {
            var startPos = message.selectionStart; //position du curseur au début de la sélection
            var endPos = message.selectionEnd; //position du curseur en fin de sélection
            var chaine = message.value;
            var startChaine = chaine.substring(0, startPos);
            var middleChaine = chaine.substring(startPos, endPos);
            var endChaine =  chaine.substring(endPos, chaine.length);
            if (defaultText=="")
            {
                //startPos==endPos
                message.value = startChaine + startTag + middleChaine + endTag + endChaine;
            }
            else
            {
                message.value = startChaine + defaultText + " " + endChaine;
            }
            //message.selectionStart = startPos + defaultText.length;
            //message.selectionEnd = endPos + defaultText.length;
            message.focus();
      }
      else message.value += startTag+defaultText+endTag;
   }
}
</script>
<?php if (isset($_GET['position'])){
echo '<script type="text/javascript">
      function Scroller() {
      var phpScroll2 = '.$_GET['position'].'; 
        window.scrollTo(0,phpScroll2);
 }
</script>';
}
?>

<script type="text/javascript">
function pos(){
var trs = document.documentElement.scrollTop;
// Stockage de la variable trs dans le champs caché portant le même nom
document.getElementById('position').value = trs;
}

</script>
</head>