<?php session_start();
$position=$_POST['position'];

require 'texte1.php';

$contenu=$_POST['message'];

$req=$bdd1->prepare('UPDATE retok SET contenu=:contenu');
$req->execute(array('contenu'=>$contenu));

$_SESSION['message']="Page enregistrée";
header("Location:paiement-ok-ch.php?position=".$position);