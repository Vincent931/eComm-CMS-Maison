<?php session_start();

$id=$_POST['id_effacer'];

require 'boutique0.php';

$req=$bdd->prepare('DELETE FROM produits WHERE id=:id');
$req->execute(array('id'=>$id));

$exist="non";
$oui="oui";
$non="non";

$req4=$bdd->query('SELECT * FROM produits WHERE (nom) LIKE "%telechargement%" ORDER BY id');
while($donnees4=$req4->fetch()){
	if(isset($donnees4['nom']) AND !empty($donnees4['nom'])){

	$exist="oui";

	$req6=$bdd->prepare('DELETE FROM download WHERE exist=:exist');
	$req6->execute(array('exist'=>$oui));

	$req7=$bdd->prepare('DELETE FROM download WHERE exist=:exist');
	$req7->execute(array('exist'=>$non));

	$req5=$bdd->prepare('INSERT INTO download(exist) VALUES(?)');
	$req5->execute(array($oui));
	}
}

if($exist=="non"){

	$req6=$bdd->prepare('DELETE FROM download WHERE exist=:exist');
	$req6->execute(array('exist'=>$non));

	$req7=$bdd->prepare('DELETE FROM download WHERE exist=:exist');
	$req7->execute(array('exist'=>$oui));

	$req5=$bdd->prepare('INSERT INTO download(exist) VALUES(?)');
	$req5->execute(array($non));
}

header("Location: effacer-telechargement.php");