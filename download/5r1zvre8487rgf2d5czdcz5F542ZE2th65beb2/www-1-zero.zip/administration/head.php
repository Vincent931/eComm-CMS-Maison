<head>
    <meta charset="utf-8"/>
    <link href="../css/style.css" rel="stylesheet"/>
    <link rel="shortcut icon" href="../publicimgs/icone.png"/>
    <?php $req50=$bdd->query('SELECT css FROM css');
    $donnees50=$req50->fetch();
    $css=$donnees50['css'];?>
    <style type="text/css"><? echo $css;?></style>
    <title>Boutique-Administration</title>
</head>