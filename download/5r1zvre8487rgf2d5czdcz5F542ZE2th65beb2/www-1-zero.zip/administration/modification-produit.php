<?php session_start(); 

require 'boutique0.php';

$_SESSION['compteur']=0;
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
	<body>
		<div>
      <h1>Espace d'administration</h1>
  <?php require 'menu-haut.php';?>
</br></br></br></br>
			<h2 style="text-align:center">Modification de produit</h2>
			<div id="boutons_connect">
				<tr>
					<td>
						<a style="border:1px solid black;color:white;text-decoration:none;background-color:#B058CE" href="../index.php">Aller sur le site</a>
					</td>
				</tr>

			</div></br>
<?php 
if(isset($_SESSION['message'])){echo '<h3 style="text-align:center;color:red">'.$_SESSION['message'].'</h3>';$_SESSION['message']="";}
?>

<form style="width:550px;margin:auto;text-align:right" method="POST" action="modification-produit.list.php">
				<p><label for="id_modifier">Numéro </label><input type="number" name="id_modifier" id="id_modifier"/></p>
				<p style="text-align:center"><input type="submit" value="Envoyer"/></p>
</form>
<?php

$req = $bdd->query('SELECT id, afficher, cle_image, titre, description, prix, TVA, promotion, quantite, livraison, livraison_associe, livraison_poly, livr_inter, poids, DATE_FORMAT(date_creation, \'%d/%m/%Y\') AS date_creation FROM produits ORDER BY id ');
while ($donnees = $req->fetch())
{
	if($donnees['promotion']=='oui'){
		$ifpromo="oui";
	} else {$ifpromo="non";}

	$req2=$bdd->prepare('SELECT * FROM explications WHERE id_produit=?');
	$req2->execute(array(htmlspecialchars($donnees['id'])));
	$donnees2=$req2->fetch();

	require 'affichage-prod.php'; 
	if(isset($donnees2['id']) AND !empty($donnees2['id'])){require 'affichage-explic.php';}
	?>
<p style="background-color:black;width:80%;margin-left:auto;margin-right:auto;height:1.5px"></p>
<?php
} 
$req->closeCursor();
$req2->closeCursor();
?>				
				
		</div>
      <br><br><br><br><br>
	</body>
</html>