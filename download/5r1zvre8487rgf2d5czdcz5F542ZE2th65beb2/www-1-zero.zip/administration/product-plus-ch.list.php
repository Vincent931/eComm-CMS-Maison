<?php session_start();

require 'boutique0.php';

if( isset($_POST['cle_image']) AND isset($_POST['afficher']) AND isset($_POST['titre']) AND isset($_POST['description']) AND isset($_POST['prix']) AND isset($_POST['quantite'])){
	if( !empty($_POST['cle_image'])) {
		if( !empty($_POST['afficher'])){
			if( !empty($_POST['titre'])) {
				if(!empty($_POST['description'])){
					if(!empty($_POST['prix'])){
						if(!empty($_POST['quantite'])){
							if(!empty($_POST['TVA'])){
								if(!empty($_POST['livraison'])){
									$livraison=htmlspecialchars($_POST['livraison']);}
									else { $livraison="";}
								if(!empty($_POST['livraison_associe'])){
									$livraison_associe=htmlspecialchars($_POST['livraison_associe']);}
									else { $livraison_associe="";}
								if(!empty($_POST['livraison_poly'])){
									$livraison_poly=htmlspecialchars($_POST['livraison_poly']);}
									else { $livraison_poly="";}		
								if(!empty($_POST['livr_inter'])){
									$livr_inter=htmlspecialchars($_POST['livr_inter']);}
									else { $livr_inter="";}	
								if(!empty($_POST['poids'])){
									$poids=htmlspecialchars($_POST['poids']);}
									else { $poids="";}
								if(!empty($_POST['promotion'])){
									$promotion=htmlspecialchars($_POST['promotion']);}
									else { $promotion="";}
								$afficher = 'non';
								$cle_image = $_POST['cle_image'];
								$titre = htmlspecialchars($_POST['titre']);
								$description = htmlspecialchars($_POST['description']);
								$prix = htmlspecialchars($_POST['prix']);
								$TVA = htmlspecialchars($_POST['TVA']);
								$quantite = htmlspecialchars($_POST['quantite']);
								$afficher_prod_solo=htmlspecialchars($_POST['afficher']);
								if(!empty($_POST['precisiona'])){
									$precisiona=htmlspecialchars($_POST['precisiona']);}
									else{$precisiona="";}
								if(!empty($_POST['image1'])){
									$image1=htmlspecialchars($_POST['image1']);}
									else{$image1="";}
								if(!empty($_POST['image2'])){
									$image2=htmlspecialchars($_POST['image2']);}
									else{$image2="";}

								$nom='prod_solo';
								$image3="";
								
								$req=$bdd->prepare('SELECT * FROM produits WHERE nom=?');
								$req->execute(array($nom));
								$donnees=$req->fetch();

								if(isset($donnees['nom']) AND $donnees['nom']=='prod_solo'){

								$id_produit=$donnees['id'];

								$req1=$bdd->prepare('UPDATE produits SET nom=:nom, afficher=:afficher, cle_image=:cle_image, titre=:titre, description=:description, prix=:prix, TVA=:TVA, promotion=:promotion, quantite=:quantite, livraison=:livraison, livraison_associe=:livraison_associe, livraison_poly=:livraison_poly, livr_inter=:livr_inter, poids=:poids WHERE nom=:nom');

								$req1->execute(array('nom'=>$nom, 'afficher'=>$afficher, 'cle_image'=>$cle_image, 'titre'=>$titre, 'description'=>$description, 'prix'=>$prix, 'TVA'=>$TVA, 'promotion'=>$promotion, 'quantite'=>$quantite, 'livraison'=>$livraison, 'livraison_associe'=>$livraison_associe, 'livraison_poly'=>$livraison_poly, 'livr_inter'=>$livr_inter,'poids'=>$poids, 'nom'=>$nom));
						
								$req2=$bdd->prepare('UPDATE explications SET precisiona=:precisiona, image1=:image1, image2=:image2, image3=:image3 WHERE id_produit=:id_produit');
								$req2->execute(array('precisiona'=>$precisiona, 'image1'=>$image1, 'image2'=>$image2, 'image3'=>$image3, 'id_produit'=>$id_produit));
								
								$req3=$bdd->prepare('UPDATE prod_solo SET afficher=:afficher');
								$req3->execute(array('afficher'=>$afficher_prod_solo));

								} else {

								$req1 = $bdd->prepare('INSERT INTO produits(nom, afficher, cle_image, titre, description, prix, TVA, promotion, quantite, livraison, livraison_associe, livraison_poly, livr_inter, poids, date_creation) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())');
								$req1->execute(array($nom, $afficher, $cle_image, $titre, $description, $prix, $TVA, $promotion, $quantite, $livraison, $livraison_associe, $livraison_poly, $livr_inter, $poids));

								$req4=$bdd->query('SELECT id FROM produits WHERE nom=\'prod_solo\'');
								$donnees2=$req4->fetch();
								$id_produit=$donnees2['id'];

								$req2=$bdd->prepare('INSERT INTO explications(id_produit, precisiona, image1, image2, image3) VALUES(?, ?, ?, ?, ?)');
								$req2->execute(array($id_produit, $precisiona, $image1, $image2, $image3));

								$req3=$bdd->prepare('INSERT INTO prod_solo(afficher) VALUES(?)');
								$req3->execute(array($afficher_prod_solo));
								
								}

								$req->closeCursor();
								$req1->closeCursor();
								$req2->closeCursor();

								$_SESSION['message']='Produit ajouté à la base de données';

							}else {$_SESSION['message']='Vous devez remplir le champx Taux TVA';}
						} else {$_SESSION['message']='Vous devez remplir le champ Quantité';}
					} else {$_SESSION['message']='Vous devez remplir le champ Prix';}
				} else {$_SESSION['message']='Vous devez remplir le champ Description';}
			} else {$_SESSION['message']='Vous devez remplir le champ Titre';}
		} else {$_SESSION['message']='Vous devez remplir champs Afficher, (oui/non)';}
	} else {$_SESSION['message']='Vous devez remplir le champ Nom-image';}
} else {$_SESSION['message']='Le formulaire est corrompu';}
header("Location: product-plus-ch.php");
//echo $id_produit.'--'.$precisiona.'--'.$image1.'--'.$image2.'--'.$image3;