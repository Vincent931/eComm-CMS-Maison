<div id="nav_admin">
  <ul class="niveau1">
    <li id="a123">Administration
      <ul id="niveau2">
        <li><a style="text-decoration:none" href="index.php">Administration</a></li>
        <li><a style="text-decoration:none" href="societe-ch.php">Entrer Informations Société</a></li>
        <li><a style="text-decoration:none" href="monetico-ch.php">Monético</a></li>
        <li><a style="text-decoration:none" href="paypal-ch.php">Paypal braintree</a></li> 
        <li><a style="text-decoration:none" href="google-ch.php">Google Maps</a></li>
        <li><a style="text-decoration:none" href="facebook-ch.php">Facebook</a></li>
        <li><a style="text-decoration:none" href="comptes.php">Afficher Comptes</a></li>
        <li><a style="text-decoration:none" href="ajouter-compte.php">Ajouter Compte</a></li>
        <li><a style="text-decoration:none" href="stock-factures.php">Ventes/Stock/Factures</a></li>
        <li><a style="text-decoration:none" href="operations-perdues.php">Opérations Perdues</a></li>
        <li><a style="text-decoration:none" href="incident-paiement.php">Incident de Paiement</a></li>
        <li><a style="text-decoration:none" href="blacklist.php">Blacklist par IP</a></li>
      </ul>
    </li>
    <li id="a123">Images/PDF/Mails
      <ul id="niveau2">
        <li><a style="text-decoration:none" href="charger-image.php">Uploader image</a></li>
        <li><a style="text-decoration:none" href="lister-image.php">Lister image</a></li>
        <li><a style="text-decoration:none" href="icones-bandeau.php">Icônes internes</a></li>
        <li><a style="text-decoration:none" href="videos-upload.php">Vidéos</a></li>
        <li><a style="text-decoration:none" href="lister-videos.php">Lister vidéos</a></li>
        <li><a style="text-decoration:none" href="music-upload.php">Musiques</a></li>
        <li><a style="text-decoration:none" href="lister-musique.php">Lister Musiques</a></li>
        <li><a style="text-decoration:none" href="charger-pdf.php">Uploader PDF</a></li>
        <li><a style="text-decoration:none" href="effacer-pdf.php">Effacer PDF</a></li>
        <li><a style="text-decoration:none" href="mail-init-ch.php">Mail création Compte</a></li>
        <li><a style="text-decoration:none" href="mail-reinit-ch.php">Mail réinitialisation Compte</a></li>
        <li><a style="text-decoration:none" href="mail-achat-ch.php">Mail validation Achat</a></li>
        <li><a style="text-decoration:none" href="mailing.php">Mailing campaign</a></li>
      </ul>
    </li>
    <li id="a123">Pages/css Add
      <ul id="niveau2">
        <li><a style="text-decoration:none" href="html-basic.php" target="_blank">A Savoir</a></li>
        <li><a style="text-decoration:none" href="color-ch.php">Couleurs</a></li>
        <li><a style="text-decoration:none" href="accueil-ch.php">Accueil</a></li>
        <li><a style="text-decoration:none" href="policy-ch.php">Politique de Confidentialité</a></li>
        <li><a style="text-decoration:none" href="contact-ch.php">Contact</a></li>
        <li><a style="text-decoration:none" href="cgv-ch.php">CGV</a></li>
        <li><a style="text-decoration:none" href="paiement-ok-ch.php">Paiement-OK</a></li>
        <li><a style="text-decoration:none" href="paiement-error-ch.php">Paiement-ERROR</a></li>
        <li><a style="text-decoration:none" href="product-plus-ch.php">Produit Solo</a></li>
        <li><a style="text-decoration:none" href="menu-haut-ch.php">Intitulé Menu Haut</a></li>
        <li><a style="text-decoration:none" href="menu-bas-ch.php">Intitulé Menu Bas</a></li>
        <li><a style="text-decoration:none" href="publicite-ch.php">Publicité Zone 1 & 2</a></li>
        <li><a style="text-decoration:none" href="css.php">Add css</a></li>
      </ul>
    </li>
    <li id="a123">Sujet/Commmentaires
      <ul id="niveau2">
        <li><a style="text-decoration:none" href="deposer.un.topic.php">Déposer un sujet</a></li>
        <li><a style="text-decoration:none" href="effacer-sujet.php">Effacer sujet</a></li>
        <li><a style="text-decoration:none" href="modification-sujet.php">Modifier sujet</a></li>
        <li><a style="text-decoration:none" href="changer-ordre-sujet.php">Modifier ordre sujet</a></li>
        <li><a style="text-decoration:none" href="effacer-commentaire.php">Effacer commentaire</a></li>
      </ul>
    </li>
    <li id="a123">Produit
      <ul id="niveau2">
        <li><a style="text-decoration:none" href="ajouter-produit.php">Ajouter produit</a></li>
        <li><a style="text-decoration:none" href="effacer-produit.php">Effacer produit</a></li>
        <li><a style="text-decoration:none" href="ajouter-explication.php">Ajouter produit-explication</a></li>
        <li><a style="text-decoration:none" href="effacer-explication.php">Effacer produit-explication</a></li>
        <li><a style="text-decoration:none" href="modification-produit.php">Modifier produit/explication</a></li>
        <li><a style="text-decoration:none" href="upload-telechargement.php">Uploader Fichier Téléchargement</a></li>
        <li><a style="text-decoration:none" href="ajouter-telechargement.php">Ajouter téléchargement</a></li>
        <li><a style="text-decoration:none" href="effacer-telechargement.php">Effacer téléchargement</a></li>
        <li><a style="text-decoration:none" href="ajouter-explication-telechargement.php">Ajouter téléchargement-explication</a></li>
        <li><a style="text-decoration:none" href="effacer-explication-telechargement.php">Effacer téléchargement-explication</a></li>
        <li><a style="text-decoration:none" href="modification-telechargement.php">Modifier téléchargement/explication</a></li>
        <li><a style="text-decoration:none" href="changer-ordre.php">Changer ordre produits</a></li>
        <li><a style="text-decoration:none" href="coupon-reduction.php">Ajouter Coupon Réduction</a></li>
      </ul>
    </li>
  </ul>  
</div>
