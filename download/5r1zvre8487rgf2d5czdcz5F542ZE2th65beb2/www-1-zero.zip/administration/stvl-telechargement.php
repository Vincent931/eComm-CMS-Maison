<?php session_start();

require 'boutique0.php';

if(isset($_POST['image']) AND !empty($_POST['image'])){
	if(isset($_POST['afficher']) AND !empty($_POST['afficher'])){
		if(isset($_POST['titre']) AND !empty($_POST['titre'])) {
			if(isset($_POST['description'])){
				if(isset($_POST['prix']) AND !empty($_POST['prix'])) {
					if(isset($_POST['quantite']) AND !empty($_POST['quantite'])) {
						if(isset($_POST['TVA']) AND !empty($_POST['TVA'])) {
							if(isset($_POST['livraison']) AND !empty($_POST['livraison'])) {
								if(isset($_POST['telechargement'])){
								$livraison=htmlspecialchars($_POST['livraison']);}
								else { $livraison="";}
							if(isset($_POST['livraison_associe']) AND !empty($_POST['livraison_associe'])) {
								$livraison_associe=htmlspecialchars($_POST['livraison_associe']);}
								else { $livraison_associe="";}
							if(isset($_POST['livr_inter']) AND !empty($_POST['livr_inter'])){
								$livr_inter=htmlspecialchars($_POST['livr_inter']);}
								else{ $livr_inter="";}
							if(isset($_POST['poids']) AND !empty($_POST['poids'])){
								$poids=htmlspecialchars($_POST['poids']);}
								else{ $poids="";}
							if(isset($_POST['livraison_poly']) AND !empty($_POST['livraison_poly'])) {
								$livraison_poly=htmlspecialchars($_POST['livraison_poly']);}
								else { $livraison_poly="";}
							if(isset($_POST['precisiona']) AND !empty($_POST['precisiona'])) {
								$precisiona=htmlspecialchars($_POST['precisiona']);}
								else { $precisiona="";}
							if(isset($_POST['image1']) AND !empty($_POST['image1'])) {
								$image1=htmlspecialchars($_POST['image1']);}
								else { $image1="";}
							if(isset($_POST['image2']) AND !empty($_POST['image2'])) {
								$image2=htmlspecialchars($_POST['image2']);}
								else { $image2="";}
							if(isset($_POST['image3']) AND !empty($_POST['image3'])) {
								$image3=htmlspecialchars($_POST['image3']);}
								else { $image3="";}
							if(isset($_POST['promotion']) AND !empty($_POST['promotion'])) {
								$promotion=htmlspecialchars($_POST['promotion']);}
								else { $promotion="";}
						$image=htmlspecialchars($_POST['image']);
						$afficher=htmlspecialchars($_POST['afficher']);
						$titre=htmlspecialchars($_POST['titre']);
						$description=htmlspecialchars($_POST['description']);
						$prix=htmlspecialchars($_POST['prix']);
						$quantite=htmlspecialchars($_POST['quantite']);
						$TVA=htmlspecialchars($_POST['TVA']);
						$nom="telechargement".$_POST['telechargement'];

						$id_modifier=htmlspecialchars($_POST['id_modifier']);

						$req=$bdd->prepare('UPDATE produits SET nom=:nom, afficher=:afficher, cle_image=:cle_image, titre=:titre, description=:description, prix=:prix, TVA=:TVA, promotion=:promotion, quantite=:quantite, livraison=:livraison, livraison_associe=:livraison_associe, livraison_poly=:livraison_poly, livr_inter=:livr_inter, poids=:poids WHERE id=:id_modifier');

						$req->execute(array('nom'=>$nom, 'afficher'=>$afficher, 'cle_image'=>$image, 'titre'=>$titre, 'description'=>$description, 'prix'=>$prix, 'TVA'=>$TVA, 'promotion'=>$promotion, 'quantite'=>$quantite, 'livraison'=>$livraison, 'livraison_associe'=>$livraison_associe, 'livraison_poly'=>$livraison_poly, 'livr_inter'=>$livr_inter,'poids'=>$poids, 'id_modifier'=>$id_modifier));
						
						$req2=$bdd->prepare('UPDATE explications SET precisiona=:precisiona, image1=:image1, image2=:image2, image3=:image3 WHERE id_produit=:id_produit');
						$req2->execute(array('precisiona'=>$precisiona, 'image1'=>$image1, 'image2'=>$image2, 'image3'=>$image3, 'id_produit'=>$id_modifier));

						$req->closeCursor();
						$req2->closeCursor();

						$_SESSION['message']='Valeur d\'affichage modifiée id N°'.$id_modifier.'';
							}else{ $_SESSION['message']='Veuillez remplir le champ Téléchargement avant de valider le formulaire';}
						} else { $_SESSION['message']='Veuillez remplir le champs Taux TVA avant de valider le formulaire';}
					} else { $_SESSION['message']='Veuillez remplir le champs Quantite avant de valider le formulaire.';}
				} else { $_SESSION['message']='Veuillez remplir le champs Prix avant de valider le formulaire.';}
			} else { $_SESSION['message']='Veuillez remplir le champs Description avant de valider le formulaire.';}
		} else { $_SESSION['message']='Veuillez remplir le champs Titre avant de valider le formulaire.';}
	} else { $_SESSION['message']='Veuillez remplir le champs Afficher avant de valider le formulaire.';}
} else { $_SESSION['message']='Veuillez remplir le champs Nom-image avant de valider le formulaire.';}
header("Location: modification-telechargement.php");