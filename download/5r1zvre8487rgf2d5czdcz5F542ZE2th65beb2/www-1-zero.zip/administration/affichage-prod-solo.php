<table id="largeur_table">
		<tr>
			<td><img style="text-align:center;width:450px;border-radius:25px/25px;border:1px solid black;margin:auto" src="../publicimgs/<?php if($ifpromo=='oui'){echo 'promo-'.htmlspecialchars($donnees['cle_image']);}else{echo htmlspecialchars($donnees['cle_image']);} ?>"/></td>
		</tr>
		<tr>
			<td><h3 style="color:blue;text-align:center;margin:auto"><?php echo htmlspecialchars($donnees['titre']); ?></h3>
			<h4 style="text-align:center;margin:auto"><?php echo htmlspecialchars($donnees['description']); ?></h4>
			<p style="color:blue;text-align:center;margin:auto"><?php echo htmlspecialchars($donnees['prix']); ?> €</p>
			</td>
		</tr>
</table>