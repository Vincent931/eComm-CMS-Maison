<?php session_start();

if(!empty($_POST['id_modifier']) AND !empty($_POST['date_creation']) AND !empty($_POST['titre1']) AND !empty($_POST['contenu1']))
	{				
		$id_modifier=htmlspecialchars($_POST['id_modifier']);
		$titre1=htmlspecialchars($_POST['titre1']);
		$contenu1=htmlspecialchars($_POST['contenu1']);
		$date_creation=htmlspecialchars($_POST['date_creation']);
		require 'blog2.php';
			//écriture du billet avec prepare
			$req = $bdd2->prepare('UPDATE topics SET titre1=:titre1, contenu1=:contenu1, date_creation=:date_creation WHERE id=:id_modifier');
			$req->execute(array('titre1'=>$titre1,
			'contenu1'=>$contenu1,
			'date_creation'=>$date_creation,
			'id_modifier'=>$id_modifier));
			$req->closeCursor();
			$req=$bdd2->prepare('SELECT id FROM topics WHERE titre1=?');
			$req->execute(array($titre1));
			$donnees1=$req->fetch();
			$req2=$bdd2->prepare('UPDATE commentaires SET id_sujet=:id_sujet WHERE id_sujet=:id_sujet');
			$req2->execute(array('id_sujet'=>htmlspecialchars($donnees1['id']),
			'id_sujet'=>$id_modifier));
					
} else { $_SESSION['message']='Vous devez remplir correctement tous les champs';
header("Location: modification-sujet.php");}

header("Location:modification-sujet.php");

?>