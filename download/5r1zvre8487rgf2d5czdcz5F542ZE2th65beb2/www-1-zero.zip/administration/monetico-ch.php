<?php session_start();

require 'boutique0.php';
require 'texte1.php';
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
	<body>
		<div>
      <h1>Espace d'administration</h1>
  <?php require 'menu-haut.php';?>
</br></br></br></br>
			<h2 style="text-align:center">Configurer Monético</h2>
			<div id="boutons_connect">
				<tr>
					<td>
						<a style="border:1px solid black;color:white;text-decoration:none;background-color:#B058CE" href="../index.php">Aller sur le site</a>
					</td>
				</tr>

			</div></br>
			
<?php
if(isset($_SESSION['message'])){echo '<h3 style="background-color:white;color:red">'.$_SESSION['message'].'</h3>';$_SESSION['message']="";}
$req=$bdd1->query('SELECT * FROM monetico');
$donnees=$req->fetch();
?>
			<p>Contactez un conseiller CIC ou Crédit Mutuel, Fournissez ces 2 urls:</p>
			<p>https://monsite.com/paiement/retour-ok.php</p>
			<p>https://monsite.com/paiement/retour-error.php</p>
			<p>Remplacer https://monsite.com par votre url.</p>
			<p>Valider 3 achats sur la plateforme de test avant de renseigner l'url de production.</p>
			<p>Test : https://p.monetico-services.com/test/ --- Production : https://p.monetico-services.com/paiement.cgi/</p>
			<p>Clé Mac : renseignez la bonne clé (1 en téléchargements, 1 en visible sur l'espace Monético).</p>
			<br><br>
			<p>Solution de Paiement</p>
			<form style="width:550px;margin:auto;text-align:right" method="POST" action="monetico-ch.list.php">
				
				<p><label for="hash">Clé de Hashage (Hmac)</label>
				<input type="text" name="hash" id="hash" value="<?php echo $donnees['hash']; ?>"/></p>

				<p><label for="TPE">Numéro de TPE</label>
				<input type="text" name="TPE" id="TPE" value="<?php echo $donnees['TPE']; ?>"/></p>
				
				<p><label for="version">Numéro de version (3.0)</label>
				<input type="text" name="version" id="version" value="<?php echo $donnees['version']; ?>"/></p>
 				
 				<p><label for="url">url serveur</label>
 				<input type="text" name="url" id="url" value="<?php echo $donnees['url']; ?>"/></p>

 				<p><label for="code">code société</label>
				<input type="text" name="code" id="code" value="<?php echo $donnees['code']; ?>"/></p>

				<p><label for="url_web">url du site (https://monsite.com)</label>
				<input type="text" name="url_web" id="url_web" value="<?php echo $donnees['url_web']; ?>"/></p>

				<p style="text-align:center"><input style="border:1px solid black;vertical-align:top;margin-top:15px" type="submit" value="Valider"/></p>
				
			</form>
		</div>
		  <br><br><br><br><br>
	</body>
</html>