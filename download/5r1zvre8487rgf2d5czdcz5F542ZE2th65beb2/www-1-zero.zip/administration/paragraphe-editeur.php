<p>Pour les liens remplacer https://urlainserer par l'url souhaité.</p>
<p>Pour les images remplacer exempledenom.jpg par le nom de votre image, effacer ;border-radius:10px/10px;border:1px solid black pour obtenir des angles droits dans les coins sans trait</p>
<p>Pour ajouter une video changer video.mp4 par le nom de votre video. et imageassocie.jpg par le nom de votre image. Ajouter un id= ou laissez le width à 300.</p>
<p>Pour une vidéo youtube rdv sur la page de votre vidéo cliquez Partager puis Intégrer et copier coller le code.</p>