<?php session_start();
require 'boutique0.php';
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
	<body>
		<div>
      <h1>Espace d'administration</h1>
  <?php require 'menu-haut.php';?>
</br></br></br></br>
			<h2 style="text-align:center">Déposer un sujet</h2>
			<div id="boutons_connect">
				<img src="../publicimgs/personne_icone.png" style="width:45px">
				<tr>
					<td>
						<a style="border:1px solid black;color:white;text-decoration:none;background-color:#B058CE" href="../index.php">Aller sur le site</a>
					</td>
				</tr>
			</div></br>
            <section>
            	<article>
<?php if(isset($_SESSION['erreur'])) {
            //echo '<font color="red">'.$_SESSION['erreur']."</font>";
				?><h4 style="background-color:red;text-align:center"><?php echo htmlspecialchars($_SESSION['erreur']); ?></h4>
				<?php 
            $_SESSION['erreur']= ''; } ?>
<form action="deposer.un.topic.list.php" method="post">
			    <div id="bloc_envoi">
			       	<p>
					        <textarea style="margin-top:2.5%" name="titre_envoi" rows="4" cols="50" placeholder="Titre"/></textarea><br />
					        <textarea style="margin-top:2.5%" name="contenu_envoi" rows="7" cols="50" placeholder="Contenu"/></textarea><br />
					        <input style="margin-top:1.25%" type="submit" name="form_topic" value="Je soumets mon topic" />
					</p>
				</div>
	</form>
</br></br>
</article>
</section>			
	
		</div>
      <br><br><br><br><br>
	</body>
</html>