<?php session_start();

$old_session_id=session_id();
$_SESSION['destroyed']=time();


if(isset($_SESSION['destroyed']) AND $_SESSION['destroyed']>time()-300)
{
  session_regenerate_id();
}
require 'texte1.php';
$req20=$bdd1->query('SELECT * FROM nav_haut');
$nav_haut=$req20->fetch();
$req21=$bdd1->query('SELECT * FROM accueil');
$accueil=$req21->fetch();
$req22=$bdd1->query('SELECT * FROM nav_bas');
$nav_bas=$req22->fetch();
$req23=$bdd1->query('SELECT * FROM title');
$title=$req23->fetch();
$req26=$bdd1->query('SELECT * FROM societe');
$ste=$req26->fetch();
require 'boutique0.php';
$req25=$bdd->query('SELECT * FROM pdf');
$pdf=$req25->fetch();
?>
<!DOCTYPE html>
<html id="bloc_page">
<?php require 'head.php';?>
   <body>         
      <?php require 'menu-haut.php';?>
            </br></br></br></br>

   <h1><?php echo $ste['nom'].' : '.$ste['sigle'];?></h1>
      <h2 style="text-align:center;margin:auto"> - Factures - </h2>
         <div id="boutons_connect">
            <img src="publicimgs/personne_icone.png" style="width:45px">
         </div>          
                 
   <section>
      <article>
<?php

$oui='oui';
if(isset($_SESSION['mail']) AND !empty($_SESSION['mail'])) {
   $mail=htmlspecialchars($_SESSION['mail']);
   $ref="1";
   $req = $bdd->prepare('SELECT reference, acheteur, DATE_FORMAT(date_com, \'%d/%m/%Y\') AS date_com FROM commande WHERE etat=? AND acheteur = ?');
   $req->execute(array($oui, $mail));
while($donnees = $req->fetch()){
 if(isset($ref)AND !empty($ref)){
   if($ref!=$donnees['reference']){
      $ref=$donnees['reference'];?>
         <table>
            <tr>
               <td>Vente du <?php echo $donnees['date_com'];?> <a style="text-decoration:underline" href="facture-pdf.php?mail=<?php echo htmlspecialchars(urlencode($donnees['acheteur']));?>&ref=<?php echo htmlspecialchars($donnees['reference']) ?>" target="_blank">N° Réf : <?php echo htmlspecialchars(urlencode($donnees['reference'])); ?></a></td>
            </tr>
         </table>
      </br>
  <?php  
}
}
} 
} else {?>
<p>Vous devez vous connecter pour accéder aux factures <a href="blog/mon-compte.php">Connectez-vous ici</a>.</p>
<p>Ou réinitialisez votre <a href="reinitialisation.php">compte.</a></p>
<?php
}?>   
</br></br></br></br><br><br>
      </article>
   </section>
             
      <?php require 'footer-fact.php'; ?>
      <?php require 'footer-resp-fact.php';?>
   </body>
</html>